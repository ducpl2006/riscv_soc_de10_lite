`ifndef SOC_MAP_VH
`define SOC_MAP_VH

// Shared RTL address map and packed response lanes. Lane n owns bit n in
// req/ready/err and bits [n*32 +: 32] in rdata. Keep existing lane ABI stable.
`define SOC_SLAVE_COUNT 7
`define SOC_SLAVE_ROM   0
`define SOC_SLAVE_RAM   1
`define SOC_SLAVE_GPIO  2
`define SOC_SLAVE_UART  3
`define SOC_SLAVE_I2C   4
`define SOC_SLAVE_QNN   5
`define SOC_SLAVE_TIMER 6

`define SOC_ROM_BASE    32'h0000_0000
`define SOC_RAM_BASE    32'h1000_0000
`define SOC_GPIO_BASE   32'h2000_0000
`define SOC_UART_BASE   32'h2000_1000
`define SOC_I2C_BASE    32'h2000_2000
`define SOC_QNN_BASE    32'h2000_3000
`define SOC_TIMER_BASE  32'h2000_4000

// Standard peripherals expose 16 bytes; QNN owns its complete 4 KiB page.
`define SOC_MMIO_MASK   32'hFFFF_FFF0
`define SOC_QNN_MASK    32'hFFFF_F000

`endif
