`default_nettype none

`include "soc_map.vh"

// Single-master, 32-bit word bus. No queue: master holds the complete request
// until req && ready at a rising edge. Errors terminate with ready && err.
// Slave lanes: 0 ROM, 1 RAM, 2 GPIO, 3 UART, 4 I2C, 5 extension/QNN, 6 timer.
// Address/data/write strobes are broadcast by the integration layer; only the
// selected slave receives req. Reserved addresses never alias a register.
module soc_bus #(
    // Dung lượng ROM theo số word 32 bit; số byte bằng ROM_WORDS*4.
    parameter integer ROM_WORDS = 8192,
    // Dung lượng SRAM theo số word 32 bit; số byte bằng RAM_WORDS*4.
    parameter integer RAM_WORDS = 2048
) (
    // Master request. Address is a byte address aligned to a 32-bit word.
    // Reset tích cực cao: decoder tổ hợp khóa request và response ngay khi rst=1.
    input  wire         rst_i,
    // Yêu cầu truy cập slave; master giữ payload đến cạnh req && ready.
    input  wire         req_i,
    // 1: yêu cầu ghi, 0: đọc; chỉ có ý nghĩa khi req=1.
    input  wire         we_i,
    // Địa chỉ byte toàn cục của CPU, phải căn 4; decoder chọn ROM/RAM/MMIO.
    input  wire [31:0]  addr_i,
    // Master response. ready && err terminates a failed transaction.
    // Dữ liệu đọc; master chỉ sử dụng khi req && ready && !we && !err.
    output reg  [31:0]  rdata_o,
    // Hoàn tất giao dịch tại cạnh req && ready; có thể kèm err.
    output reg          ready_o,
    // Lỗi địa chỉ/quyền truy cập; master chỉ xét khi req && ready.
    output reg          err_o,
    // Packed slave lanes, indexed by SOC_SLAVE_* from soc_map.vh.
    // Bit SOC_SLAVE_* chọn slave; tối đa một bit bằng 1, reset/idle bằng 0.
    output reg  [`SOC_SLAVE_COUNT-1:0]    slave_req_o,
    // Lane n dùng [n*32 +: 32]; response phải khớp lane request được chọn.
    input  wire [`SOC_SLAVE_COUNT*32-1:0] slave_rdata_i,
    // Bit n báo hoàn tất từ slave n; chỉ lane được chọn được trả về master.
    input  wire [`SOC_SLAVE_COUNT-1:0]    slave_ready_i,
    // Bit n báo lỗi từ slave n; chỉ xét cùng ready của chính lane đó.
    input  wire [`SOC_SLAVE_COUNT-1:0]    slave_err_i
);
    localparam [31:0] ROM_BYTES = ROM_WORDS * 4;
    localparam [31:0] RAM_BYTES = RAM_WORDS * 4;
    // Chỉ số slave đã giải mã; -1 nghĩa là địa chỉ/quyền truy cập không hợp lệ.
    integer selected;

    always @* begin
        selected = -1;
        rdata_o = 32'd0;
        ready_o = 1'b0;
        err_o = 1'b0;
        slave_req_o = {`SOC_SLAVE_COUNT{1'b0}};
        if (req_i && !rst_i) begin
            if (addr_i[1:0] == 2'b00) begin
                if (addr_i < ROM_BYTES && !we_i)
                    selected = `SOC_SLAVE_ROM;
                else if (addr_i >= `SOC_RAM_BASE &&
                         (addr_i - `SOC_RAM_BASE) < RAM_BYTES)
                    selected = `SOC_SLAVE_RAM;
                else if ((addr_i & `SOC_MMIO_MASK) == `SOC_GPIO_BASE)
                    selected = `SOC_SLAVE_GPIO;
                else if ((addr_i & `SOC_MMIO_MASK) == `SOC_UART_BASE)
                    selected = `SOC_SLAVE_UART;
                else if ((addr_i & `SOC_MMIO_MASK) == `SOC_I2C_BASE)
                    selected = `SOC_SLAVE_I2C;
                else if ((addr_i & `SOC_QNN_MASK) == `SOC_QNN_BASE)
                    selected = `SOC_SLAVE_QNN;
                else if ((addr_i & `SOC_MMIO_MASK) == `SOC_TIMER_BASE)
                    selected = `SOC_SLAVE_TIMER;
            end
            if (selected < 0) begin
                ready_o = 1'b1;
                err_o = 1'b1;
            end
            else begin
                slave_req_o[selected] = 1'b1;
                ready_o = slave_ready_i[selected];
                err_o = slave_ready_i[selected] && slave_err_i[selected];
                if (slave_ready_i[selected] && !slave_err_i[selected])
                    rdata_o = slave_rdata_i[selected*32 +: 32];
            end
        end
    end
endmodule

`default_nettype wire
