`default_nettype none

// =============================================================================
// Module      : soc_gpio
// Chức năng   : GPIO MMIO cho 10 LED và 10 switch của DE10-Lite.
// Thanh ghi   : 0x0 LED_RW, 0x4 SWITCH_RO.
// =============================================================================
module soc_gpio (
    // Clock hệ thống; mạch tuần tự cập nhật tại cạnh lên.
    input  wire        clk_i,
    // Reset tích cực cao; xóa trạng thái tại cạnh lên, đồng thời chặn giao dịch mới.
    input  wire        rst_i,
    // Yêu cầu truy cập slave; master giữ payload đến cạnh req && ready.
    input  wire        req_i,
    // 1: yêu cầu ghi, 0: đọc; chỉ có ý nghĩa khi req=1.
    input  wire        we_i,
    // Offset byte MMIO: 0x0 LED đọc/ghi, 0x4 SWITCH chỉ đọc.
    input  wire [3:0]  addr_i,
    // Dữ liệu ghi 32 bit; chỉ các byte được wstrb chọn mới được cập nhật.
    input  wire [31:0] wdata_i,
    // Bit n chọn byte [8*n +: 8]; không chọn byte nào vẫn phải kiểm tra quyền/địa chỉ.
    input  wire [3:0]  wstrb_i,
    // Dữ liệu đọc; master chỉ sử dụng khi req && ready && !we && !err.
    output reg  [31:0] rdata_o,
    // Hoàn tất giao dịch tại cạnh req && ready; có thể kèm err.
    output wire        ready_o,
    // Lỗi địa chỉ/quyền truy cập; master chỉ xét khi req && ready.
    output reg         err_o,
    // Mức của 10 switch đã đồng bộ với clk_i tại lớp board.
    input  wire [9:0]  switches_i,
    // Giá trị thanh ghi GPIO 10 bit; lớp board quyết định ánh xạ ra LED vật lý.
    output wire [9:0]  leds_o
);

    // Thanh ghi 10 LED; cập nhật riêng byte thấp và hai bit cao theo wstrb.
    reg [9:0] leds_q;
    assign leds_o  = leds_q;
    assign ready_o = req_i && !rst_i;

    always @* begin
        rdata_o = 32'd0;
        err_o   = 1'b0;
        case (addr_i)
            4'h0: rdata_o = {22'd0, leds_q};
            4'h4: rdata_o = {22'd0, switches_i};
            default: err_o = ready_o;
        endcase
        if (ready_o && we_i && (addr_i != 4'h0))
            err_o = 1'b1;
    end

    always @(posedge clk_i) begin
        if (rst_i)
            leds_q <= 10'd0;
        else if (ready_o && we_i && !err_o) begin
            if (wstrb_i[0]) leds_q[7:0] <= wdata_i[7:0];
            if (wstrb_i[1]) leds_q[9:8] <= wdata_i[9:8];
        end
    end

endmodule

`default_nettype wire
