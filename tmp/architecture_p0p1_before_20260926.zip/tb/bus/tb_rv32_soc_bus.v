`timescale 1ns/1ps
`default_nettype none

module tb_rv32_soc_bus;
    reg rst, req, we;
    reg [31:0] addr;
    wire [31:0] rdata;
    wire ready, err;
    wire [6:0] select;
    reg [223:0] slave_data;
    reg [6:0] slave_ready, slave_err;
    integer checks, lane, offset;
    reg [31:0] base;

    soc_bus #(.ROM_WORDS(16), .RAM_WORDS(8)) dut (
        .rst_i(rst), .req_i(req), .we_i(we), .addr_i(addr),
        .rdata_o(rdata), .ready_o(ready), .err_o(err), .slave_req_o(select),
        .slave_rdata_i(slave_data), .slave_ready_i(slave_ready), .slave_err_i(slave_err)
    );

    task check_access;
        input [31:0] address;
        input write_access;
        input integer expected_lane;
        begin
            addr = address; we = write_access; req = 1; #1;
            if (expected_lane < 0) begin
                if (select !== 0 || !ready || !err || rdata !== 0)
                    $fatal(1, "Decode error addr=%h select=%b", addr, select);
            end
            else if (select !== (7'b1 << expected_lane) || !ready || err ||
                     rdata !== (32'hA0000000 + expected_lane))
                $fatal(1, "Decode lane %0d addr=%h select=%b", expected_lane, addr, select);
            checks = checks + 1;
        end
    endtask

    initial begin
        rst = 0; req = 0; we = 0; addr = 0; checks = 0;
        slave_ready = 7'h7F; slave_err = 0;
        for (lane = 0; lane < 7; lane = lane + 1)
            slave_data[lane*32 +: 32] = 32'hA0000000 + lane;
        #1;
        if (ready || err || select || rdata) $fatal(1, "Idle outputs");
        check_access(0, 0, 0);
        check_access(60, 0, 0);
        check_access(64, 0, -1);
        check_access(0, 1, -1);
        check_access(32'h10000000, 1, 1);
        check_access(32'h1000001C, 0, 1);
        check_access(32'h10000020, 1, -1);
        check_access(32'h0FFFFFFC, 0, -1);
        check_access(32'hFFFFFFFF, 0, -1);
        for (lane = 2; lane < 7; lane = lane + 1) begin
            base = 32'h20000000 + (lane - 2) * 4096;
            for (offset = 0; offset < 4096; offset = offset + 4)
                check_access(base + offset, 0, (lane == 5 || offset < 16) ? lane : -1);
            check_access(base + 1, 0, -1);
            check_access(base + 2, 1, -1);
        end
        check_access(32'h20005000, 0, -1);
        // Unselected response/error must never leak; selected err is sampled at ready.
        addr = 32'h10000000; we = 0; slave_ready = 7'b1111101; slave_err = 7'h7F;
        #1;
        if (ready || err || rdata || select !== 7'b10) $fatal(1, "Wait-state isolation");
        slave_ready[1] = 1; #1;
        if (!ready || !err || rdata) $fatal(1, "Slave error propagation");
        rst = 1; #1;
        if (ready || err || select || rdata) $fatal(1, "Reset isolation");
        rst = 0; req = 0; #1;
        if (ready || err || select || rdata) $fatal(1, "Idle isolation");
        $display("PASS tb_rv32_soc_bus: %0d address checks plus response/reset isolation", checks);
        $finish;
    end
endmodule

`default_nettype wire
