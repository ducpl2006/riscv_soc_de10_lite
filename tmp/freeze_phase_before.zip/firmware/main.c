#include <stdint.h>
#include "include/soc_map.h"
#include "include/model_config.h"

/*
 * Firmware tham chiếu cho luồng đo INA219 -> cửa sổ 20 mẫu -> QNN -> UART/LED.
 * Code chỉ dùng số nguyên, không phụ thuộc hệ điều hành hay thư viện C runtime.
 * Các hệ số chuẩn hóa và trọng số demo phải được thay bởi output của pipeline ML.
 */

#define INA219_ADDRESS 0x40u
#define INA219_REG_SHUNT_VOLTAGE 0x01u
#define INA219_REG_BUS_VOLTAGE   0x02u
#define SAMPLE_PERIOD_CYCLES     500000000u /* 10 s tại 50 MHz */

static int8_t feature_window[MODEL_INPUT_COUNT];

static void uart_putc(char value)
{
    while ((UART_STATUS & UART_TX_READY) == 0u) { }
    UART_DATA = (uint32_t)(uint8_t)value;
}

static void uart_put_u32(uint32_t value)
{
    char digits[10];
    uint32_t count = 0u;
    if (value == 0u) {
        uart_putc('0');
        return;
    }
    while (value != 0u) {
        digits[count++] = (char)('0' + value % 10u);
        value /= 10u;
    }
    while (count != 0u)
        uart_putc(digits[--count]);
}

static int i2c_execute(uint32_t command)
{
    /* command: START/STOP/READ/NACK; trả 1 chỉ khi byte hoàn tất không lỗi.
     * Watchdog RTL kết thúc chờ bus bị kẹt; không coi timeout là mẫu đo hợp lệ. */
    I2C_COMMAND = command | I2C_CMD_EXECUTE | I2C_CMD_CLEAR_ERRORS;
    while ((I2C_STATUS & I2C_BUSY) != 0u) { }
    if ((I2C_STATUS & I2C_ERROR_MASK) == 0u)
        return 1;
    /* Một lần phục hồi có giới hạn; luôn bỏ mẫu lỗi, không lặp vô hạn.
     * Cờ lỗi của recovery được giữ để chẩn đoán tới lệnh kế tiếp. */
    I2C_COMMAND = I2C_CMD_RECOVER | I2C_CMD_CLEAR_ERRORS;
    while ((I2C_STATUS & I2C_BUSY) != 0u) { }
    return 0;
}

static int ina219_read_register(uint8_t reg, uint16_t *value)
{
    uint8_t high;
    uint8_t low;

    I2C_DATA = (INA219_ADDRESS << 1);
    if (!i2c_execute(I2C_CMD_START)) return 0;
    I2C_DATA = reg;
    if (!i2c_execute(0u)) return 0;
    I2C_DATA = (INA219_ADDRESS << 1) | 1u;
    if (!i2c_execute(I2C_CMD_START)) return 0;
    if (!i2c_execute(I2C_CMD_READ)) return 0;
    high = (uint8_t)I2C_DATA;
    if (!i2c_execute(I2C_CMD_READ | I2C_CMD_NACK | I2C_CMD_STOP)) return 0;
    low = (uint8_t)I2C_DATA;
    *value = ((uint16_t)high << 8) | low;
    return 1;
}

static int8_t quantize_feature(int32_t raw, uint32_t feature)
{
    int32_t q = (raw - model_feature_center[feature]) /
                model_feature_scale[feature];
    if (q > 127) q = 127;
    if (q < -128) q = -128;
    return (int8_t)q;
}

static void append_sample(int32_t voltage_mv, int32_t current_ma,
                          int32_t temperature_deci_c, int32_t delta_ms)
{
    uint32_t i;
    for (i = 0u; i < MODEL_INPUT_COUNT - MODEL_FEATURE_COUNT; ++i)
        feature_window[i] = feature_window[i + MODEL_FEATURE_COUNT];

    feature_window[76] = quantize_feature(voltage_mv, MODEL_VOLTAGE);
    feature_window[77] = quantize_feature(current_ma, MODEL_CURRENT);
    feature_window[78] = quantize_feature(temperature_deci_c, MODEL_TEMPERATURE);
    feature_window[79] = quantize_feature(delta_ms, MODEL_DELTA_TIME);
}

static uint32_t run_qnn(void)
{
    uint32_t i;
    for (i = 0u; i < MODEL_INPUT_COUNT; ++i)
        QNN_FEATURE(i) = (uint32_t)(uint8_t)feature_window[i];
    QNN_CONTROL = QNN_START;
    while ((QNN_STATUS & QNN_DONE) == 0u) { }
    return QNN_RESULT;
}

static void wait_sample_period(void)
{
    uint32_t deadline = TIMER_TIME_LO + SAMPLE_PERIOD_CYCLES;
    while ((int32_t)(TIMER_TIME_LO - deadline) < 0) { }
}

int main(void)
{
    uint16_t bus_raw;
    uint16_t shunt_raw;
    uint32_t soc_deci_percent;
    uint32_t warmup = 0u;

    uart_putc('B'); uart_putc('O'); uart_putc('O'); uart_putc('T'); uart_putc('\n');

    for (;;) {
        if (ina219_read_register(INA219_REG_BUS_VOLTAGE, &bus_raw) &&
            ina219_read_register(INA219_REG_SHUNT_VOLTAGE, &shunt_raw)) {
            /* INA219: bus voltage LSB 4 mV; shunt LSB 10 uV.
             * current_ma cần hệ số shunt thực tế; demo giả sử 0,1 ohm. */
            int32_t voltage_mv = (int32_t)((bus_raw >> 3) * 4u);
            int32_t current_ma = (int32_t)(int16_t)shunt_raw / 10;
            append_sample(voltage_mv, current_ma, 250, 10000);
            if (warmup < MODEL_SEQUENCE_LENGTH)
                ++warmup;
            if (warmup == MODEL_SEQUENCE_LENGTH) {
                soc_deci_percent = run_qnn();
                GPIO_LED = soc_deci_percent >> 2;
                uart_putc('S'); uart_putc('O'); uart_putc('C'); uart_putc('=');
                uart_put_u32(soc_deci_percent / 10u);
                uart_putc('.'); uart_putc((char)('0' + soc_deci_percent % 10u));
                uart_putc('%'); uart_putc('\n');
            }
        }
        else {
            uart_putc('I'); uart_putc('2'); uart_putc('C'); uart_putc('!'); uart_putc('\n');
        }
        wait_sample_period();
    }
}
