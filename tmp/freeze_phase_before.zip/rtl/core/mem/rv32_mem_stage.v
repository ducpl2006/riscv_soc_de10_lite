`default_nettype none
`include "rv32_defs.vh"

// MEM: giao dịch dữ liệu word, phát hiện chờ/lỗi và chọn dữ liệu ghi về WB.
// Logic tổ hợp; core giữ EX/MEM và toàn bộ payload khi req && !ready.
// Giao dịch hoàn tất tại cạnh req && ready; err chỉ có nghĩa tại cạnh đó.
// Chi tiết bus dữ liệu: docs/giao_tiep_rtl_vi.md, mục 3.
module rv32_mem_stage (
    // Reset tích cực cao; logic tổ hợp chặn phát dmem_req khi reset.
    input  wire         rst_i,
    // Core đã dừng do trap; giữ mức 1 đến reset.
    input  wire         halted_i,
    // Lệnh lỗi hợp lệ tại WB; sự kiện chốt trap và hủy các lệnh trẻ hơn.
    input  wire         wb_trap_event_i,
    // 1: tầng đang chứa một lệnh; 0: bubble, không được tạo tác dụng phụ.
    input  wire         valid_i,
    // 1: lệnh đã mang ngoại lệ; chặn thực thi/ghi kết quả thông thường.
    input  wire         exc_valid_i,
    // 1: lệnh đọc bộ nhớ; cỡ đọc và mở rộng dấu do funct3 quyết định.
    input  wire         load_i,
    // 1: lệnh ghi bộ nhớ; cỡ ghi do funct3 quyết định.
    input  wire         store_i,
    // Kết quả ALU 32 bit; với load/store là địa chỉ byte hiệu dụng.
    input  wire [31:0]  alu_result_i,
    // Giá trị rs2 đã forwarding, chốt ở EX/MEM để tạo dữ liệu store.
    input  wire [31:0]  store_data_i,
    // Trường instr[14:12], chọn điều kiện nhánh hoặc cỡ/kiểu load-store.
    input  wire [2:0]   funct3_i,
    // Chọn nguồn ghi về: RV32_WB_ALU / LOAD / PC4.
    input  wire [1:0]   wb_sel_i,
    // PC + 4 của lệnh đang xét; địa chỉ trở về cho JAL/JALR.
    input  wire [31:0]  pc4_i,
    // Word đọc từ bus; chỉ dùng khi req && ready && !we && !err.
    input  wire [31:0]  dmem_rdata_i,
    // Hoàn tất giao dịch tại cạnh req && ready, kể cả khi err=1.
    input  wire         dmem_ready_i,
    // Lỗi data bus; chỉ có nghĩa khi req && ready, sinh cause 5/7.
    input  wire         dmem_err_i,
    // Yêu cầu load/store; giữ nguyên payload tới cạnh req && ready.
    output wire         dmem_req_o,
    // 1: ghi, 0: đọc; bằng 0 khi không có yêu cầu dữ liệu.
    output wire         dmem_we_o,
    // Địa chỉ byte đã căn xuống biên 4 byte; LSU xử lý byte lane riêng.
    output wire [31:0]  dmem_addr_o,
    // Dữ liệu store đã đặt vào đúng byte lane của word 32 bit.
    output wire [31:0]  dmem_wdata_o,
    // Bit n cho phép ghi byte [8*n +: 8]; bằng 0 khi không ghi.
    output wire [3:0]   dmem_wstrb_o,
    // 1 khi req && !ready: core phải giữ EX/MEM và payload bus.
    output wire         stall_o,
    // Giao dịch dữ liệu kết thúc có lỗi: dmem_req && dmem_ready && dmem_err.
    output wire         fault_raw_o,
    // Dữ liệu 32 bit đã chọn để ghi về thanh ghi đích.
    output reg  [31:0]  wb_data_o
);
    localparam [1:0] WB_LOAD = `RV32_WB_LOAD;
    localparam [1:0] WB_PC4 = `RV32_WB_PC4;

    // Địa chỉ byte đã căn word đưa lên dmem_addr.
    wire [31:0] mem_lsu_addr;
    // Dữ liệu store sau đặt vào đúng byte lane.
    wire [31:0] mem_lsu_wdata;
    // Byte-enable do LSU sinh; chỉ đưa lên bus khi dmem_we=1.
    wire [3:0]  mem_lsu_wstrb;
    // Dữ liệu load đã căn lane và mở rộng dấu/zero để ghi rd.
    wire [31:0] mem_load_data;
    // Đầu ra phụ không sử dụng tại tầng này; nối tên riêng để thể hiện chủ đích.
    wire        mem_lsu_misaligned_unused;

    rv32_lsu u_lsu_mem (
        .addr_i         (alu_result_i),
        .funct3_i       (funct3_i),
        .load_en_i      (load_i),
        .store_en_i     (store_i),
        .store_data_i   (store_data_i),
        .load_data_i    (dmem_rdata_i),
        .mem_addr_o     (mem_lsu_addr),
        .mem_wdata_o    (mem_lsu_wdata),
        .mem_wstrb_o    (mem_lsu_wstrb),
        .load_data_o    (mem_load_data),
        .misaligned_o   (mem_lsu_misaligned_unused)
    );

    assign dmem_req_o = valid_i && !exc_valid_i &&
                        (load_i || store_i) &&
                        !rst_i && !halted_i && !wb_trap_event_i;
    assign dmem_we_o    = dmem_req_o && store_i;
    assign dmem_addr_o  = mem_lsu_addr;
    assign dmem_wdata_o = mem_lsu_wdata;
    assign dmem_wstrb_o = dmem_we_o ? mem_lsu_wstrb : 4'b0000;

    // Giao dịch hoàn tất tại cạnh lên khi req && ready, kể cả giao dịch lỗi.
    wire dmem_fire;

    assign dmem_fire    = dmem_req_o && dmem_ready_i;
    assign stall_o    = dmem_req_o && !dmem_ready_i;
    assign fault_raw_o = dmem_fire && dmem_err_i;

    always @(*) begin
        case (wb_sel_i)
            WB_LOAD: wb_data_o = mem_load_data;
            WB_PC4 : wb_data_o = pc4_i;
            default: wb_data_o = alu_result_i;
        endcase
    end

endmodule

`default_nettype wire
