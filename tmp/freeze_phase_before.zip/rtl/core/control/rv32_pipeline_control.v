`default_nettype none

// Điều khiển pipeline tổ hợp; lỗi/redirect của lệnh già hơn chặn sự kiện trẻ hơn.
// MEM chờ thì giữ EX/MEM và ID/EX; WB cũ vẫn được commit đúng một lần.
// ifid_consumed xác nhận lấy đầu FIFO tại cạnh lên; không phải tín hiệu ready
// của memory. Core áp dụng reset và trap WB với ưu tiên cao nhất.
// Chi tiết ưu tiên và điều kiện chuyển: docs/giao_tiep_rtl_vi.md, mục 5.
module rv32_pipeline_control (
    // ID: Chỉ số thanh ghi nguồn rs1 (0..31); không phải địa chỉ bộ nhớ.
    input  wire [4:0]   id_rs1_addr_i,
    // ID: Chỉ số thanh ghi nguồn rs2 (0..31); không phải địa chỉ bộ nhớ.
    input  wire [4:0]   id_rs2_addr_i,
    // ID: 1: lệnh thực sự đọc rs1; dùng để tránh báo hazard giả.
    input  wire         id_uses_rs1_i,
    // ID: 1: lệnh thực sự đọc rs2; dùng để tránh báo hazard giả.
    input  wire         id_uses_rs2_i,
    // ID/EX: 1: tầng đang chứa một lệnh; 0: bubble, không được tạo tác dụng phụ.
    input  wire         idex_valid_i,
    // ID/EX: 1: lệnh đã mang ngoại lệ; chặn thực thi/ghi kết quả thông thường.
    input  wire         idex_exc_valid_i,
    // ID/EX: 1: lệnh đọc bộ nhớ; cỡ đọc và mở rộng dấu do funct3 quyết định.
    input  wire         idex_load_i,
    // ID/EX: Chỉ số thanh ghi đích rd (0..31); ghi x0 bị bỏ qua tại commit.
    input  wire [4:0]   idex_rd_addr_i,
    // ID/EX: Chỉ số thanh ghi nguồn rs1 (0..31); không phải địa chỉ bộ nhớ.
    input  wire [4:0]   idex_rs1_addr_i,
    // ID/EX: Chỉ số thanh ghi nguồn rs2 (0..31); không phải địa chỉ bộ nhớ.
    input  wire [4:0]   idex_rs2_addr_i,
    // EX/MEM: 1: tầng đang chứa một lệnh; 0: bubble, không được tạo tác dụng phụ.
    input  wire         exmem_valid_i,
    // EX/MEM: 1: lệnh đã mang ngoại lệ; chặn thực thi/ghi kết quả thông thường.
    input  wire         exmem_exc_valid_i,
    // EX/MEM: Yêu cầu ghi rd; còn phải kiểm tra valid, ngoại lệ và rd khác x0.
    input  wire         exmem_reg_write_i,
    // EX/MEM: 1: lệnh đọc bộ nhớ; cỡ đọc và mở rộng dấu do funct3 quyết định.
    input  wire         exmem_load_i,
    // EX/MEM: Chỉ số thanh ghi đích rd (0..31); ghi x0 bị bỏ qua tại commit.
    input  wire [4:0]   exmem_rd_addr_i,
    // MEM/WB: 1: tầng đang chứa một lệnh; 0: bubble, không được tạo tác dụng phụ.
    input  wire         memwb_valid_i,
    // MEM/WB: 1: lệnh đã mang ngoại lệ; chặn thực thi/ghi kết quả thông thường.
    input  wire         memwb_exc_valid_i,
    // MEM/WB: Yêu cầu ghi rd; còn phải kiểm tra valid, ngoại lệ và rd khác x0.
    input  wire         memwb_reg_write_i,
    // MEM/WB: Chỉ số thanh ghi đích rd (0..31); ghi x0 bị bỏ qua tại commit.
    input  wire [4:0]   memwb_rd_addr_i,
    // Lỗi data bus tại cạnh req && ready; chưa qua điều khiển pipeline.
    input  wire         mem_fault_raw_i,
    // MEM đang chờ data ready; giữ các tầng phía trước, WB cũ vẫn hoàn tất một lần.
    input  wire         mem_stall_i,
    // Lỗi căn chỉnh tại EX; đã xét valid/ngoại lệ, chưa xét MEM stall.
    input  wire         ex_fault_raw_i,
    // EX: Yêu cầu nhảy/nhánh lấy; bộ điều khiển còn phải xét valid và ngoại lệ.
    input  wire         ex_control_taken_i,
    // EX: Đích nhánh/jump đang lấy không chia hết cho 4; cần cause 0.
    input  wire         ex_target_misaligned_i,
    // IF/ID: 1: tầng đang chứa một lệnh; 0: bubble, không được tạo tác dụng phụ.
    input  wire         ifid_valid_i,
    // IF/ID: 1: lệnh đã mang ngoại lệ; chặn thực thi/ghi kết quả thông thường.
    input  wire         ifid_exc_valid_i,
    // ID: Ngoại lệ do giải mã: illegal, EBREAK hoặc ECALL; chưa xét valid tầng.
    input  wire         id_decode_exc_i,
    // Core đã dừng do trap; giữ mức 1 đến reset.
    input  wire         halted_i,
    // Lệnh lỗi hợp lệ tại WB; sự kiện chốt trap và hủy các lệnh trẻ hơn.
    input  wire         wb_trap_event_i,
    // Chọn rs1: 00=ID/EX, 01=WB, 10=MEM; không forward load sớm từ MEM.
    output wire [1:0]   forward_rs1_sel_o,
    // Chọn rs2: 00=ID/EX, 01=WB, 10=MEM; MEM ưu tiên hơn WB.
    output wire [1:0]   forward_rs2_sel_o,
    // Lỗi MEM được đưa tới điều khiển để loại các lệnh trẻ hơn.
    output wire         mem_fault_event_o,
    // Lỗi EX được xử lý khi MEM không stall và không có lỗi già hơn.
    output wire         ex_fault_event_o,
    // Nhánh/jump hợp lệ đổi PC; hủy lệnh trẻ và đáp ứng fetch sai đường.
    output wire         ex_redirect_event_o,
    // Ngoại lệ ID được xử lý sau khi loại các sự kiện ưu tiên ở MEM/EX.
    output wire         id_exception_event_o,
    // Dừng ID và chèn bubble vào EX vì dữ liệu load chưa sẵn sàng.
    output wire         load_use_stall_o,
    // Xác nhận lấy đầu FIFO IF/ID tại cạnh lên; chỉ phát khi ID được tiến.
    output wire         ifid_consumed_o
);
    // Hazard load-use trước khi phân xử với stall MEM và flush do lỗi/redirect.
    wire       load_use_stall_raw;

    rv32_hazard_unit u_hazard_unit (
        .id_rs1_addr_i    (id_rs1_addr_i),
        .id_rs2_addr_i    (id_rs2_addr_i),
        .id_uses_rs1_i    (id_uses_rs1_i),
        .id_uses_rs2_i    (id_uses_rs2_i),
        .ex_valid_i       (idex_valid_i && !idex_exc_valid_i),
        .ex_load_i        (idex_load_i),
        .ex_rd_addr_i     (idex_rd_addr_i),
        .ex_rs1_addr_i    (idex_rs1_addr_i),
        .ex_rs2_addr_i    (idex_rs2_addr_i),
        .mem_valid_i      (exmem_valid_i && !exmem_exc_valid_i),
        .mem_reg_write_i  (exmem_reg_write_i),
        .mem_load_i       (exmem_load_i),
        .mem_rd_addr_i    (exmem_rd_addr_i),
        .wb_valid_i       (memwb_valid_i && !memwb_exc_valid_i),
        .wb_reg_write_i   (memwb_reg_write_i),
        .wb_rd_addr_i     (memwb_rd_addr_i),
        .stall_load_use_o (load_use_stall_raw),
        .forward_rs1_o    (forward_rs1_sel_o),
        .forward_rs2_o    (forward_rs2_sel_o)
    );

    assign mem_fault_event_o = mem_fault_raw_i;
    assign ex_fault_event_o = ex_fault_raw_i && !mem_stall_i &&
                            !mem_fault_event_o;
    assign ex_redirect_event_o = idex_valid_i && !idex_exc_valid_i &&
                               ex_control_taken_i && !ex_target_misaligned_i &&
                               !mem_stall_i && !mem_fault_event_o;
    assign id_exception_event_o = ifid_valid_i && !ifid_exc_valid_i &&
                                id_decode_exc_i && !mem_stall_i &&
                                !mem_fault_event_o && !ex_fault_event_o &&
                                !ex_redirect_event_o;
    assign load_use_stall_o = load_use_stall_raw && !mem_stall_i &&
                            !mem_fault_event_o && !ex_fault_event_o &&
                            !ex_redirect_event_o;

    // Cho phép ID tiến khi không halt, trap, stall hoặc sự kiện MEM/EX ưu tiên.
    wire id_can_advance;

    assign id_can_advance = !halted_i && !wb_trap_event_i && !mem_stall_i &&
                            !mem_fault_event_o && !ex_fault_event_o &&
                            !ex_redirect_event_o && !load_use_stall_o;
    assign ifid_consumed_o = ifid_valid_i && id_can_advance;

endmodule

`default_nettype wire
