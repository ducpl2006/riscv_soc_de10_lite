`default_nettype none
`include "rv32_defs.vh"

// =============================================================================
// Module      : rv32_hazard_unit
// Chức năng   : Phát hiện hazard dữ liệu và chọn đường forwarding cho pipeline
//               RV32I 5 tầng IF/ID/EX/MEM/WB.
// Kiểu mạch   : Logic tổ hợp, không có trạng thái và không có độ trễ chu kỳ.
//
// Đặc tả giao tiếp:
//   - Nhóm id_* mô tả lệnh đang ở tầng ID. Hai cờ id_uses_rs* ngăn stall
//     giả đối với các trường bit có hình dạng giống rs1/rs2 nhưng lệnh không dùng.
//   - Nhóm ex_* dùng để phát hiện load-use. Kết quả load chưa sẵn sàng cho lệnh
//     ngay sau nó, vì vậy pipeline phải chèn đúng một bubble rồi chờ thêm nếu
//     tầng MEM bị wait-state.
//   - Nhóm mem_*/wb_* dùng để forward toán hạng cho lệnh đang ở tầng EX.
//   - Dữ liệu từ MEM có ưu tiên cao hơn WB vì đó là giá trị mới hơn. Load tại
//     MEM không được chọn: dữ liệu chỉ được chốt và forward từ WB.
//
// Mã forward:
//   2'b00: dùng dữ liệu đã chốt trong ID/EX.
//   2'b01: dùng dữ liệu write-back tại MEM/WB.
//   2'b10: dùng kết quả sớm tại EX/MEM.
//   2'b11: dự phòng, module không phát mã này.
//
// Bất biến:
//   - x0 không tạo hazard và không bao giờ là nguồn forwarding.
//   - Mọi output luôn có giá trị xác định, kể cả khi các stage không valid.
// =============================================================================
module rv32_hazard_unit (
    // ID: Chỉ số thanh ghi nguồn rs1 (0..31); không phải địa chỉ bộ nhớ.
    input  wire [4:0] id_rs1_addr_i,
    // ID: Chỉ số thanh ghi nguồn rs2 (0..31); không phải địa chỉ bộ nhớ.
    input  wire [4:0] id_rs2_addr_i,
    // ID: 1: lệnh thực sự đọc rs1; dùng để tránh báo hazard giả.
    input  wire       id_uses_rs1_i,
    // ID: 1: lệnh thực sự đọc rs2; dùng để tránh báo hazard giả.
    input  wire       id_uses_rs2_i,

    // EX: 1: tầng đang chứa một lệnh; 0: bubble, không được tạo tác dụng phụ.
    input  wire       ex_valid_i,
    // EX: 1: lệnh đọc bộ nhớ; cỡ đọc và mở rộng dấu do funct3 quyết định.
    input  wire       ex_load_i,
    // EX: Chỉ số thanh ghi đích rd (0..31); ghi x0 bị bỏ qua tại commit.
    input  wire [4:0] ex_rd_addr_i,
    // EX: Chỉ số thanh ghi nguồn rs1 (0..31); không phải địa chỉ bộ nhớ.
    input  wire [4:0] ex_rs1_addr_i,
    // EX: Chỉ số thanh ghi nguồn rs2 (0..31); không phải địa chỉ bộ nhớ.
    input  wire [4:0] ex_rs2_addr_i,

    // MEM: 1: tầng đang chứa một lệnh; 0: bubble, không được tạo tác dụng phụ.
    input  wire       mem_valid_i,
    // MEM: Yêu cầu ghi rd; còn phải kiểm tra valid, ngoại lệ và rd khác x0.
    input  wire       mem_reg_write_i,
    // MEM: 1: lệnh đọc bộ nhớ; cỡ đọc và mở rộng dấu do funct3 quyết định.
    input  wire       mem_load_i,
    // MEM: Chỉ số thanh ghi đích rd (0..31); ghi x0 bị bỏ qua tại commit.
    input  wire [4:0] mem_rd_addr_i,

    // WB: 1: tầng đang chứa một lệnh; 0: bubble, không được tạo tác dụng phụ.
    input  wire       wb_valid_i,
    // WB: Yêu cầu ghi rd; còn phải kiểm tra valid, ngoại lệ và rd khác x0.
    input  wire       wb_reg_write_i,
    // WB: Chỉ số thanh ghi đích rd (0..31); ghi x0 bị bỏ qua tại commit.
    input  wire [4:0] wb_rd_addr_i,

    // Hazard load-use thô giữa ID và EX; bộ điều khiển phân xử stall/flush.
    output reg        stall_load_use_o,
    // Chọn rs1: 00=ID/EX, 01=WB, 10=MEM; rd=x0 không được forward.
    output reg  [1:0] forward_rs1_o,
    // Chọn rs2: 00=ID/EX, 01=WB, 10=MEM; rd=x0 không được forward.
    output reg  [1:0] forward_rs2_o
);

    localparam [1:0]
        FWD_NONE = `RV32_FWD_NONE,
        FWD_WB = `RV32_FWD_WB,
        FWD_MEM = `RV32_FWD_MEM;

    always @(*) begin
        stall_load_use_o = 1'b0;
        forward_rs1_o    = FWD_NONE;
        forward_rs2_o    = FWD_NONE;

        if (ex_valid_i && ex_load_i && (ex_rd_addr_i != 5'd0)) begin
            if ((id_uses_rs1_i && (id_rs1_addr_i == ex_rd_addr_i)) ||
                (id_uses_rs2_i && (id_rs2_addr_i == ex_rd_addr_i))) begin
                stall_load_use_o = 1'b1;
            end
        end

        if (mem_valid_i && mem_reg_write_i && !mem_load_i &&
            (mem_rd_addr_i != 5'd0) &&
            (mem_rd_addr_i == ex_rs1_addr_i)) begin
            forward_rs1_o = FWD_MEM;
        end
        else if (wb_valid_i && wb_reg_write_i &&
                 (wb_rd_addr_i != 5'd0) &&
                 (wb_rd_addr_i == ex_rs1_addr_i)) begin
            forward_rs1_o = FWD_WB;
        end

        if (mem_valid_i && mem_reg_write_i && !mem_load_i &&
            (mem_rd_addr_i != 5'd0) &&
            (mem_rd_addr_i == ex_rs2_addr_i)) begin
            forward_rs2_o = FWD_MEM;
        end
        else if (wb_valid_i && wb_reg_write_i &&
                 (wb_rd_addr_i != 5'd0) &&
                 (wb_rd_addr_i == ex_rs2_addr_i)) begin
            forward_rs2_o = FWD_WB;
        end
    end

endmodule

`default_nettype wire
