`default_nettype none
`include "rv32_defs.vh"

// WB: commit thanh ghi, trace lệnh hoàn tất và chốt ngoại lệ chính xác.
// Cạnh lên thực hiện commit khi MEM/WB hợp lệ, không lỗi và core chưa halt.
// Trace có nghĩa trong chu kỳ ngay sau cạnh commit; trap/halt giữ tới reset.
// Lệnh lỗi không retire và không ghi rd. Reset đồng bộ, tích cực cao.
// Chi tiết trace/trap: docs/giao_tiep_rtl_vi.md, mục 6.
module rv32_wb_stage (
    // Clock hệ thống; mạch tuần tự cập nhật tại cạnh lên.
    input  wire         clk_i,
    // Reset tích cực cao; xóa trạng thái tại cạnh lên, đồng thời chặn giao dịch mới.
    input  wire         rst_i,
    // 1: tầng đang chứa một lệnh; 0: bubble, không được tạo tác dụng phụ.
    input  wire         valid_i,
    // 1: lệnh đã mang ngoại lệ; chặn thực thi/ghi kết quả thông thường.
    input  wire         exc_valid_i,
    // Yêu cầu ghi rd; còn phải kiểm tra valid, ngoại lệ và rd khác x0.
    input  wire         reg_write_i,
    // Chỉ số thanh ghi đích rd (0..31); ghi x0 bị bỏ qua tại commit.
    input  wire [4:0]   rd_addr_i,
    // Dữ liệu 32 bit đã chọn để ghi về thanh ghi đích.
    input  wire [31:0]  wb_data_i,
    // Địa chỉ byte của lệnh đang xét, dùng cho đích nhánh và trace/trap.
    input  wire [31:0]  pc_i,
    // Mã lệnh RV32I 32 bit của lệnh đang xét.
    input  wire [31:0]  instr_i,
    // Mã nguyên nhân ngoại lệ; chỉ có nghĩa khi exc_valid=1.
    input  wire [4:0]   exc_cause_i,
    // Cho phép commit rd tại cạnh lên; đã chặn reset, lỗi, halt và x0.
    output wire         wb_regfile_we_o,
    // Lệnh lỗi hợp lệ tại WB; sự kiện chốt trap và hủy các lệnh trẻ hơn.
    output wire         wb_trap_event_o,
    // Core đã dừng do trap; giữ mức 1 đến reset.
    output reg          halted_o,
    // Ngoại lệ đã commit tại WB; giữ 1 cùng metadata trap đến reset.
    output reg          trap_valid_o,
    // Mã ngoại lệ đã chốt; có nghĩa khi trap_valid=1.
    output reg  [4:0]   trap_cause_o,
    // PC của lệnh gây trap; có nghĩa khi trap_valid=1.
    output reg  [31:0]  trap_pc_o,
    // Mã lệnh gây trap; bằng 0 nếu lỗi fetch không có mã lệnh hợp lệ.
    output reg  [31:0]  trap_instr_o,
    // Có lệnh hoàn tất thành công ở cạnh vừa qua; có thể cao nhiều chu kỳ liên tiếp.
    output reg          retire_valid_o,
    // PC của lệnh vừa hoàn tất; chỉ dùng khi retire_valid=1.
    output reg  [31:0]  retire_pc_o,
    // Mã lệnh vừa hoàn tất; chỉ dùng khi retire_valid=1.
    output reg  [31:0]  retire_instr_o,
    // Lệnh retire có ghi rd khác x0; chỉ xét khi retire_valid=1.
    output reg          retire_rd_we_o,
    // Chỉ số rd đã ghi; chỉ dùng khi retire_valid && retire_rd_we.
    output reg  [4:0]   retire_rd_addr_o,
    // Giá trị đã ghi vào rd; chỉ dùng khi retire_valid && retire_rd_we.
    output reg  [31:0]  retire_rd_data_o
);

    assign wb_regfile_we_o = !rst_i && valid_i && !exc_valid_i &&
                           reg_write_i && (rd_addr_i != 5'd0) && !halted_o;
    assign wb_trap_event_o = valid_i && exc_valid_i && !halted_o && !rst_i;
    always @(posedge clk_i) begin
        if (rst_i) begin
            halted_o <= 1'b0;
            trap_valid_o        <= 1'b0;
            trap_cause_o        <= 5'b0;
            trap_pc_o           <= 32'b0;
            trap_instr_o        <= 32'b0;
            retire_valid_o      <= 1'b0;
            retire_pc_o         <= 32'b0;
            retire_instr_o      <= 32'b0;
            retire_rd_we_o      <= 1'b0;
            retire_rd_addr_o    <= 5'b0;
            retire_rd_data_o    <= 32'b0;
        end
        else begin
            retire_valid_o <= 1'b0;
            retire_rd_we_o <= 1'b0;

            // WB commit thanh ghi và trace; store đã hoàn tất handshake tại MEM.
            if (!halted_o && valid_i && !exc_valid_i) begin
                retire_valid_o   <= 1'b1;
                retire_pc_o      <= pc_i;
                retire_instr_o   <= instr_i;
                retire_rd_we_o   <= reg_write_i &&
                                    (rd_addr_i != 5'd0);
                retire_rd_addr_o <= rd_addr_i;
                retire_rd_data_o <= wb_data_i;
            end

            if (wb_trap_event_o) begin
                halted_o <= 1'b1;
                trap_valid_o <= 1'b1;
                trap_cause_o <= exc_cause_i;
                trap_pc_o <= pc_i;
                trap_instr_o <= instr_i;
            end
        end
    end

endmodule

`default_nettype wire
