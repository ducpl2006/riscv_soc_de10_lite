`default_nettype none
`include "rv32_defs.vh"

// ID: giải mã RV32I, tạo immediate và đọc thanh ghi có bypass từ WB.
// Giải mã tổ hợp; register file ghi/reset tại cạnh lên. Payload đầu vào chỉ
// được core sử dụng khi IF/ID hợp lệ; decode_exc không tự tạo tác dụng phụ.
// Chi tiết ranh giới pipeline: docs/giao_tiep_rtl_vi.md, mục 5.
module rv32_id_stage (
    // Clock hệ thống; mạch tuần tự cập nhật tại cạnh lên.
    input  wire         clk_i,
    // Reset tích cực cao; xóa trạng thái tại cạnh lên, đồng thời chặn giao dịch mới.
    input  wire         rst_i,
    // Mã lệnh RV32I 32 bit của lệnh đang xét.
    input  wire [31:0]  instr_i,
    // 1: lệnh đã mang ngoại lệ; chặn thực thi/ghi kết quả thông thường.
    input  wire         exc_valid_i,
    // Mã nguyên nhân ngoại lệ; chỉ có nghĩa khi exc_valid=1.
    input  wire [4:0]   exc_cause_i,
    // Cho phép commit rd tại cạnh lên; đã chặn reset, lỗi, halt và x0.
    input  wire         wb_regfile_we_i,
    // MEM/WB: Chỉ số thanh ghi đích rd (0..31); ghi x0 bị bỏ qua tại commit.
    input  wire [4:0]   memwb_rd_addr_i,
    // MEM/WB: Dữ liệu 32 bit đã chọn để ghi về thanh ghi đích.
    input  wire [31:0]  memwb_wb_data_i,
    // Chỉ số thanh ghi nguồn rs1 (0..31); không phải địa chỉ bộ nhớ.
    output wire [4:0]   rs1_addr_o,
    // Chỉ số thanh ghi nguồn rs2 (0..31); không phải địa chỉ bộ nhớ.
    output wire [4:0]   rs2_addr_o,
    // Chỉ số thanh ghi đích rd (0..31); ghi x0 bị bỏ qua tại commit.
    output wire [4:0]   rd_addr_o,
    // Trường instr[14:12], chọn điều kiện nhánh hoặc cỡ/kiểu load-store.
    output wire [2:0]   funct3_o,
    // Giá trị toán hạng nguồn rs1, rộng 32 bit.
    output wire [31:0]  rs1_data_o,
    // Giá trị toán hạng nguồn rs2, rộng 32 bit.
    output wire [31:0]  rs2_data_o,
    // Immediate 32 bit: mở rộng dấu I/S/B/J; dạng U có 12 bit thấp bằng 0.
    output wire [31:0]  imm_o,
    // Mã phép toán nội bộ RV32_ALU_* trong rv32_defs.vh.
    output wire [3:0]   alu_op_o,
    // Chọn toán hạng A: RV32_OP_A_RS1 / PC / ZERO.
    output wire [1:0]   op_a_sel_o,
    // 1: ALU lấy immediate làm B; 0: lấy giá trị rs2.
    output wire         op_b_imm_o,
    // Yêu cầu ghi rd; còn phải kiểm tra valid, ngoại lệ và rd khác x0.
    output wire         reg_write_o,
    // Chọn nguồn ghi về: RV32_WB_ALU / LOAD / PC4.
    output wire [1:0]   wb_sel_o,
    // 1: lệnh nhánh có điều kiện; chưa có nghĩa là nhánh được lấy.
    output wire         branch_o,
    // 1: lệnh JAL, nhảy tới PC + immediate và ghi PC+4 vào rd.
    output wire         jal_o,
    // 1: lệnh JALR; đích rs1 + immediate phải xóa bit 0.
    output wire         jalr_o,
    // 1: lệnh đọc bộ nhớ; cỡ đọc và mở rộng dấu do funct3 quyết định.
    output wire         load_o,
    // 1: lệnh ghi bộ nhớ; cỡ ghi do funct3 quyết định.
    output wire         store_o,
    // 1: lệnh thực sự đọc rs1; dùng để tránh báo hazard giả.
    output wire         uses_rs1_o,
    // 1: lệnh thực sự đọc rs2; dùng để tránh báo hazard giả.
    output wire         uses_rs2_o,
    // Ngoại lệ do giải mã: illegal, EBREAK hoặc ECALL; chưa xét valid tầng.
    output reg          decode_exc_o,
    // Có lỗi fetch đi kèm hoặc lỗi giải mã mới tại ID.
    output wire         any_exc_o,
    // Cause đưa sang EX; lỗi fetch có ưu tiên hơn lỗi giải mã.
    output wire [4:0]   any_exc_cause_o
);
    localparam [4:0] CAUSE_ILLEGAL_INSTRUCTION = `RV32_CAUSE_ILLEGAL_INSTRUCTION;
    localparam [4:0] CAUSE_BREAKPOINT = `RV32_CAUSE_BREAKPOINT;
    localparam [4:0] CAUSE_ECALL_MMODE = `RV32_CAUSE_ECALL_MMODE;

    // ID: Chọn dạng immediate theo RV32_IMM_* trong rv32_defs.vh.
    wire [2:0] id_imm_type;

    // ID: 1: FENCE hợp lệ; thực hiện như NOP trong core in-order hiện tại.
    wire       id_fence;
    // ID: 1: lệnh ECALL; ID tạo ngoại lệ cause 11.
    wire       id_ecall;
    // ID: 1: lệnh EBREAK; ID tạo ngoại lệ breakpoint, cause 3.
    wire       id_ebreak;
    // ID: 1: mã lệnh không hỗ trợ/không hợp lệ; các tác dụng phụ bị vô hiệu.
    wire       id_illegal;

    assign rs1_addr_o = instr_i[19:15];
    assign rs2_addr_o = instr_i[24:20];
    assign rd_addr_o  = instr_i[11:7];
    assign funct3_o   = instr_i[14:12];

    rv32_decoder u_decoder (
        .instr_i       (instr_i),
        .alu_op_o      (alu_op_o),
        .imm_type_o    (id_imm_type),
        .op_a_sel_o    (op_a_sel_o),
        .op_b_imm_o    (op_b_imm_o),
        .reg_write_o   (reg_write_o),
        .wb_sel_o      (wb_sel_o),
        .branch_o      (branch_o),
        .jal_o         (jal_o),
        .jalr_o        (jalr_o),
        .load_o        (load_o),
        .store_o       (store_o),
        .fence_o       (id_fence),
        .ecall_o       (id_ecall),
        .ebreak_o      (id_ebreak),
        .illegal_o     (id_illegal),
        .uses_rs1_o    (uses_rs1_o),
        .uses_rs2_o    (uses_rs2_o)
    );

    rv32_imm_gen u_imm_gen (
        .instr_i    (instr_i),
        .imm_type_i (id_imm_type),
        .imm_o      (imm_o)
    );

    rv32_regfile u_regfile (
        .clk_i      (clk_i),
        .rst_i      (rst_i),
        .rs1_addr_i (rs1_addr_o),
        .rs2_addr_i (rs2_addr_o),
        .rs1_data_o (rs1_data_o),
        .rs2_data_o (rs2_data_o),
        .rd_we_i    (wb_regfile_we_i),
        .rd_addr_i  (memwb_rd_addr_i),
        .rd_data_i  (memwb_wb_data_i)
    );

    // Ngoại lệ được phát hiện tại ID. Fetch fault đã có metadata riêng.

    // Cause do giải mã; chỉ dùng nếu decode_exc=1 và không có fetch fault.
    reg [4:0]  id_decode_exc_cause;
    always @(*) begin
        decode_exc_o       = 1'b0;
        id_decode_exc_cause = CAUSE_ILLEGAL_INSTRUCTION;
        if (id_illegal) begin
            decode_exc_o       = 1'b1;
            id_decode_exc_cause = CAUSE_ILLEGAL_INSTRUCTION;
        end
        else if (id_ebreak) begin
            decode_exc_o       = 1'b1;
            id_decode_exc_cause = CAUSE_BREAKPOINT;
        end
        else if (id_ecall) begin
            decode_exc_o       = 1'b1;
            id_decode_exc_cause = CAUSE_ECALL_MMODE;
        end
    end

    assign any_exc_o = exc_valid_i || decode_exc_o;
    assign any_exc_cause_o = exc_valid_i
                            ? exc_cause_i
                            : id_decode_exc_cause;

endmodule

`default_nettype wire
