`default_nettype none

`include "rv32_defs.vh"

// =============================================================================
// Module      : rv32_core
// Chức năng   : Core RV32I pipeline 5 tầng, in-order, single-issue.
// Pipeline    : IF -> ID -> EX -> MEM -> WB.
// ISA         : RV32I v2.1; không gồm C, M, A, Zicsr hay Zifencei.
//
// Giao tiếp bộ nhớ
//   - Instruction request được nhận tại req && gnt; response có rvalid riêng,
//     trả đúng thứ tự, sớm nhất ở cạnh kế tiếp. Không có rready.
//   - rdata/err instruction chỉ được lấy mẫu khi rvalid=1.
//   - Data bus giữ req và payload tới cạnh req && ready; tối đa một giao dịch.
//   - imem_addr_o là địa chỉ byte, luôn căn 4 khi phát request.
//   - dmem_addr_o là địa chỉ word đã căn; wstrb chọn byte lane little-endian.
//   - Pipeline dừng phía trước MEM khi data bus có wait-state. Instruction bus
//     dành trước chỗ trong FIFO hai phần tử cho mọi yêu cầu đã phát.
//   - Tổng FIFO, yêu cầu chờ đáp ứng và yêu cầu chờ grant không vượt hai.
//
// Hazard và control flow
//   - Forward EX/MEM -> EX và MEM/WB -> EX; EX/MEM có ưu tiên cao hơn.
//   - Load-use chèn một bubble. Nếu load bị wait-state, các tầng trước giữ lại.
//   - Branch/JAL/JALR được giải quyết tại EX; lệnh trẻ hơn bị flush khi redirect.
//   - Register file có bypass WB -> ID cho phụ thuộc cùng chu kỳ ghi.
//
// Ngoại lệ và retirement
//   - Hỗ trợ instruction/data access fault, địa chỉ lệch hàng, illegal,
//     EBREAK và ECALL. Ngoại lệ đi theo pipeline tới WB để giữ tính precise.
//   - Ngoại lệ đến WB chốt trap_valid_o và dừng core tới reset; không retire.
//   - FENCE là NOP hợp lệ: core in-order, không cache, chỉ có một data request.
//   - retire_* tạo giao tiếp trace một chu kỳ cho mỗi lệnh hoàn tất thành công.
//
// Reset
//   - rst_i tích cực mức cao, đồng bộ. PC fetch về RESET_VECTOR; pipeline rỗng.
//   - Core và memory phải reset đồng thời để hủy mọi đáp ứng cũ.
//   - Ngoài reset, yêu cầu lấy lệnh giữ tới grant, yêu cầu dữ liệu giữ tới ready.
//
// Cách đọc tên tín hiệu:
//   - _i/_o: hướng vào/ra tính tại module đang khai báo; _q: giá trị đã chốt.
//   - idex/exmem/memwb: ranh giới ID/EX, EX/MEM, MEM/WB chứa lệnh đang xử lý.
//   - ifid_*_q và halted_q là wire nối trạng thái chốt trong module con.
//   - Payload từng ranh giới chỉ có nghĩa khi valid tương ứng bằng 1;
//     exc_valid đánh dấu lệnh lỗi, không phải lệnh được phép gây tác dụng phụ.
// Đặc tả      : docs/giao_tiep_rtl_vi.md (phiên bản giao tiếp 2.0).
// =============================================================================
module rv32_core #(
    // PC khởi động (địa chỉ byte); nên căn 4, lệch hàng sẽ tạo trap tại IF.
    parameter [31:0] RESET_VECTOR = 32'h0000_0000
) (
    // Clock hệ thống; mạch tuần tự cập nhật tại cạnh lên.
    input  wire        clk_i,
    // Reset tích cực cao; xóa trạng thái tại cạnh lên, đồng thời chặn giao dịch mới.
    input  wire        rst_i,

    // Lấy lệnh: kênh yêu cầu và kênh đáp ứng tách pha, không có transaction ID.
    // Yêu cầu lấy lệnh; giữ mức 1 cùng địa chỉ tới cạnh req && gnt.
    output wire        imem_req_o,
    // Địa chỉ byte lấy lệnh, căn 4; giữ ổn định khi req && !gnt.
    output wire [31:0] imem_addr_o,
    // Memory nhận yêu cầu tại cạnh req && gnt; chưa phải dữ liệu trả về.
    input  wire        imem_gnt_i,
    // Có đáp ứng cho yêu cầu đã grant trước đó; không có rready.
    input  wire        imem_rvalid_i,
    // Word lệnh trả về; chỉ dùng khi rvalid=1 và err=0.
    input  wire [31:0] imem_rdata_i,
    // Lỗi lấy lệnh; chỉ xét cùng rvalid, tạo cause 1 nếu đúng đường.
    input  wire        imem_err_i,

    // Dữ liệu: bus word little-endian; wstrb chọn byte, err có nghĩa tại ready.
    // Yêu cầu load/store; giữ nguyên payload tới cạnh req && ready.
    output wire        dmem_req_o,
    // 1: ghi, 0: đọc; bằng 0 khi không có yêu cầu dữ liệu.
    output wire        dmem_we_o,
    // Địa chỉ byte đã căn xuống biên 4 byte; LSU xử lý byte lane riêng.
    output wire [31:0] dmem_addr_o,
    // Dữ liệu store đã đặt vào đúng byte lane của word 32 bit.
    output wire [31:0] dmem_wdata_o,
    // Bit n cho phép ghi byte [8*n +: 8]; bằng 0 khi không ghi.
    output wire [3:0]  dmem_wstrb_o,
    // Word đọc từ bus; chỉ dùng khi req && ready && !we && !err.
    input  wire [31:0] dmem_rdata_i,
    // Hoàn tất giao dịch tại cạnh req && ready, kể cả khi err=1.
    input  wire        dmem_ready_i,
    // Lỗi data bus; chỉ có nghĩa khi req && ready, sinh cause 5/7.
    input  wire        dmem_err_i,

    // Ngoại lệ: trạng thái chốt tại WB, giữ đến reset.
    // Core đã dừng do trap; giữ mức 1 đến reset.
    output wire        halted_o,
    // Ngoại lệ đã commit tại WB; giữ 1 cùng metadata trap đến reset.
    output wire        trap_valid_o,
    // Mã ngoại lệ đã chốt; có nghĩa khi trap_valid=1.
    output wire [4:0]  trap_cause_o,
    // PC của lệnh gây trap; có nghĩa khi trap_valid=1.
    output wire [31:0] trap_pc_o,
    // Mã lệnh gây trap; bằng 0 nếu lỗi fetch không có mã lệnh hợp lệ.
    output wire [31:0] trap_instr_o,

    // Trace: dữ liệu có nghĩa khi retire_valid=1; không phải giao tiếp RVFI.
    // Có lệnh hoàn tất thành công ở cạnh vừa qua; có thể cao nhiều chu kỳ liên tiếp.
    output wire        retire_valid_o,
    // PC của lệnh vừa hoàn tất; chỉ dùng khi retire_valid=1.
    output wire [31:0] retire_pc_o,
    // Mã lệnh vừa hoàn tất; chỉ dùng khi retire_valid=1.
    output wire [31:0] retire_instr_o,
    // Lệnh retire có ghi rd khác x0; chỉ xét khi retire_valid=1.
    output wire        retire_rd_we_o,
    // Chỉ số rd đã ghi; chỉ dùng khi retire_valid && retire_rd_we.
    output wire [4:0]  retire_rd_addr_o,
    // Giá trị đã ghi vào rd; chỉ dùng khi retire_valid && retire_rd_we.
    output wire [31:0] retire_rd_data_o,

    // PC cho yêu cầu fetch mới; không phải PC retire hay địa chỉ đang giữ chờ grant.
    output wire [31:0] debug_fetch_pc_o
);

    localparam [1:0] OP_A_RS1 = `RV32_OP_A_RS1;
    localparam [1:0] WB_ALU = `RV32_WB_ALU;
    localparam [4:0] CAUSE_LOAD_ACCESS_FAULT = `RV32_CAUSE_LOAD_ACCESS_FAULT;
    localparam [4:0] CAUSE_STORE_ACCESS_FAULT = `RV32_CAUSE_STORE_ACCESS_FAULT;

    // ID/EX: 1: tầng đang chứa một lệnh; 0: bubble, không được tạo tác dụng phụ.
    reg         idex_valid_q;
    // ID/EX: Địa chỉ byte của lệnh đang xét, dùng cho đích nhánh và trace/trap.
    reg  [31:0] idex_pc_q;
    // ID/EX: Mã lệnh RV32I 32 bit của lệnh đang xét.
    reg  [31:0] idex_instr_q;
    // ID/EX: PC + 4 của lệnh đang xét; địa chỉ trở về cho JAL/JALR.
    reg  [31:0] idex_pc4_q;
    // ID/EX: Chỉ số thanh ghi nguồn rs1 (0..31); không phải địa chỉ bộ nhớ.
    reg  [4:0]  idex_rs1_addr_q;
    // ID/EX: Chỉ số thanh ghi nguồn rs2 (0..31); không phải địa chỉ bộ nhớ.
    reg  [4:0]  idex_rs2_addr_q;
    // ID/EX: Chỉ số thanh ghi đích rd (0..31); ghi x0 bị bỏ qua tại commit.
    reg  [4:0]  idex_rd_addr_q;
    // ID/EX: Giá trị toán hạng nguồn rs1, rộng 32 bit.
    reg  [31:0] idex_rs1_data_q;
    // ID/EX: Giá trị toán hạng nguồn rs2, rộng 32 bit.
    reg  [31:0] idex_rs2_data_q;
    // ID/EX: Immediate 32 bit: mở rộng dấu I/S/B/J; dạng U có 12 bit thấp bằng 0.
    reg  [31:0] idex_imm_q;
    // ID/EX: Trường instr[14:12], chọn điều kiện nhánh hoặc cỡ/kiểu load-store.
    reg  [2:0]  idex_funct3_q;
    // ID/EX: Mã phép toán nội bộ RV32_ALU_* trong rv32_defs.vh.
    reg  [3:0]  idex_alu_op_q;
    // ID/EX: Chọn toán hạng A: RV32_OP_A_RS1 / PC / ZERO.
    reg  [1:0]  idex_op_a_sel_q;
    // ID/EX: 1: ALU lấy immediate làm B; 0: lấy giá trị rs2.
    reg         idex_op_b_imm_q;
    // ID/EX: Yêu cầu ghi rd; còn phải kiểm tra valid, ngoại lệ và rd khác x0.
    reg         idex_reg_write_q;
    // ID/EX: Chọn nguồn ghi về: RV32_WB_ALU / LOAD / PC4.
    reg  [1:0]  idex_wb_sel_q;
    // ID/EX: 1: lệnh nhánh có điều kiện; chưa có nghĩa là nhánh được lấy.
    reg         idex_branch_q;
    // ID/EX: 1: lệnh JAL, nhảy tới PC + immediate và ghi PC+4 vào rd.
    reg         idex_jal_q;
    // ID/EX: 1: lệnh JALR; đích rs1 + immediate phải xóa bit 0.
    reg         idex_jalr_q;
    // ID/EX: 1: lệnh đọc bộ nhớ; cỡ đọc và mở rộng dấu do funct3 quyết định.
    reg         idex_load_q;
    // ID/EX: 1: lệnh ghi bộ nhớ; cỡ ghi do funct3 quyết định.
    reg         idex_store_q;
    // ID/EX: 1: lệnh đã mang ngoại lệ; chặn thực thi/ghi kết quả thông thường.
    reg         idex_exc_valid_q;
    // ID/EX: Mã nguyên nhân ngoại lệ; chỉ có nghĩa khi exc_valid=1.
    reg  [4:0]  idex_exc_cause_q;

    // EX/MEM: 1: tầng đang chứa một lệnh; 0: bubble, không được tạo tác dụng phụ.
    reg         exmem_valid_q;
    // EX/MEM: Địa chỉ byte của lệnh đang xét, dùng cho đích nhánh và trace/trap.
    reg  [31:0] exmem_pc_q;
    // EX/MEM: Mã lệnh RV32I 32 bit của lệnh đang xét.
    reg  [31:0] exmem_instr_q;
    // EX/MEM: PC + 4 của lệnh đang xét; địa chỉ trở về cho JAL/JALR.
    reg  [31:0] exmem_pc4_q;
    // EX/MEM: Chỉ số thanh ghi đích rd (0..31); ghi x0 bị bỏ qua tại commit.
    reg  [4:0]  exmem_rd_addr_q;
    // EX/MEM: Yêu cầu ghi rd; còn phải kiểm tra valid, ngoại lệ và rd khác x0.
    reg         exmem_reg_write_q;
    // EX/MEM: Chọn nguồn ghi về: RV32_WB_ALU / LOAD / PC4.
    reg  [1:0]  exmem_wb_sel_q;
    // EX/MEM: Kết quả ALU 32 bit; với load/store là địa chỉ byte hiệu dụng.
    reg  [31:0] exmem_alu_result_q;
    // EX/MEM: giá trị rs2 sau forwarding, giữ ổn định khi store đang chờ bus.
    reg  [31:0] exmem_store_data_q;
    // EX/MEM: Trường instr[14:12], chọn điều kiện nhánh hoặc cỡ/kiểu load-store.
    reg  [2:0]  exmem_funct3_q;
    // EX/MEM: 1: lệnh đọc bộ nhớ; cỡ đọc và mở rộng dấu do funct3 quyết định.
    reg         exmem_load_q;
    // EX/MEM: 1: lệnh ghi bộ nhớ; cỡ ghi do funct3 quyết định.
    reg         exmem_store_q;
    // EX/MEM: 1: lệnh đã mang ngoại lệ; chặn thực thi/ghi kết quả thông thường.
    reg         exmem_exc_valid_q;
    // EX/MEM: Mã nguyên nhân ngoại lệ; chỉ có nghĩa khi exc_valid=1.
    reg  [4:0]  exmem_exc_cause_q;

    // MEM/WB: 1: tầng đang chứa một lệnh; 0: bubble, không được tạo tác dụng phụ.
    reg         memwb_valid_q;
    // MEM/WB: Địa chỉ byte của lệnh đang xét, dùng cho đích nhánh và trace/trap.
    reg  [31:0] memwb_pc_q;
    // MEM/WB: Mã lệnh RV32I 32 bit của lệnh đang xét.
    reg  [31:0] memwb_instr_q;
    // MEM/WB: Chỉ số thanh ghi đích rd (0..31); ghi x0 bị bỏ qua tại commit.
    reg  [4:0]  memwb_rd_addr_q;
    // MEM/WB: Yêu cầu ghi rd; còn phải kiểm tra valid, ngoại lệ và rd khác x0.
    reg         memwb_reg_write_q;
    // MEM/WB: Dữ liệu 32 bit đã chọn để ghi về thanh ghi đích.
    reg  [31:0] memwb_wb_data_q;
    // MEM/WB: 1: lệnh đã mang ngoại lệ; chặn thực thi/ghi kết quả thông thường.
    reg         memwb_exc_valid_q;
    // MEM/WB: Mã nguyên nhân ngoại lệ; chỉ có nghĩa khi exc_valid=1.
    reg  [4:0]  memwb_exc_cause_q;

    // IF/ID: 1: tầng đang chứa một lệnh; 0: bubble, không được tạo tác dụng phụ.
    wire         ifid_valid_q;
    // IF/ID: Địa chỉ byte của lệnh đang xét, dùng cho đích nhánh và trace/trap.
    wire [31:0]  ifid_pc_q;
    // IF/ID: Mã lệnh RV32I 32 bit của lệnh đang xét.
    wire [31:0]  ifid_instr_q;
    // IF/ID: 1: lệnh đã mang ngoại lệ; chặn thực thi/ghi kết quả thông thường.
    wire         ifid_exc_valid_q;
    // IF/ID: Mã nguyên nhân ngoại lệ; chỉ có nghĩa khi exc_valid=1.
    wire [4:0]   ifid_exc_cause_q;
    // ID: Chỉ số thanh ghi nguồn rs1 (0..31); không phải địa chỉ bộ nhớ.
    wire [4:0]   id_rs1_addr;
    // ID: Chỉ số thanh ghi nguồn rs2 (0..31); không phải địa chỉ bộ nhớ.
    wire [4:0]   id_rs2_addr;
    // ID: Chỉ số thanh ghi đích rd (0..31); ghi x0 bị bỏ qua tại commit.
    wire [4:0]   id_rd_addr;
    // ID: Trường instr[14:12], chọn điều kiện nhánh hoặc cỡ/kiểu load-store.
    wire [2:0]   id_funct3;
    // ID: Giá trị toán hạng nguồn rs1, rộng 32 bit.
    wire [31:0]  id_rs1_data;
    // ID: Giá trị toán hạng nguồn rs2, rộng 32 bit.
    wire [31:0]  id_rs2_data;
    // ID: Immediate 32 bit: mở rộng dấu I/S/B/J; dạng U có 12 bit thấp bằng 0.
    wire [31:0]  id_imm;
    // ID: Mã phép toán nội bộ RV32_ALU_* trong rv32_defs.vh.
    wire [3:0]   id_alu_op;
    // ID: Chọn toán hạng A: RV32_OP_A_RS1 / PC / ZERO.
    wire [1:0]   id_op_a_sel;
    // ID: 1: ALU lấy immediate làm B; 0: lấy giá trị rs2.
    wire         id_op_b_imm;
    // ID: Yêu cầu ghi rd; còn phải kiểm tra valid, ngoại lệ và rd khác x0.
    wire         id_reg_write;
    // ID: Chọn nguồn ghi về: RV32_WB_ALU / LOAD / PC4.
    wire [1:0]   id_wb_sel;
    // ID: 1: lệnh nhánh có điều kiện; chưa có nghĩa là nhánh được lấy.
    wire         id_branch;
    // ID: 1: lệnh JAL, nhảy tới PC + immediate và ghi PC+4 vào rd.
    wire         id_jal;
    // ID: 1: lệnh JALR; đích rs1 + immediate phải xóa bit 0.
    wire         id_jalr;
    // ID: 1: lệnh đọc bộ nhớ; cỡ đọc và mở rộng dấu do funct3 quyết định.
    wire         id_load;
    // ID: 1: lệnh ghi bộ nhớ; cỡ ghi do funct3 quyết định.
    wire         id_store;
    // ID: 1: lệnh thực sự đọc rs1; dùng để tránh báo hazard giả.
    wire         id_uses_rs1;
    // ID: 1: lệnh thực sự đọc rs2; dùng để tránh báo hazard giả.
    wire         id_uses_rs2;
    // ID: Ngoại lệ do giải mã: illegal, EBREAK hoặc ECALL; chưa xét valid tầng.
    wire         id_decode_exc;
    // ID: Có lỗi fetch đi kèm hoặc lỗi giải mã mới tại ID.
    wire         id_any_exc;
    // ID: Cause đưa sang EX; lỗi fetch có ưu tiên hơn lỗi giải mã.
    wire [4:0]   id_any_exc_cause;
    // EX: Giá trị rs1 sau chọn forwarding, dùng cho ALU/so sánh nhánh.
    wire [31:0]  ex_rs1_value;
    // EX: Giá trị rs2 sau forwarding, dùng cho ALU/nhánh và dữ liệu store.
    wire [31:0]  ex_rs2_value;
    // EX: Kết quả ALU 32 bit; với load/store là địa chỉ byte hiệu dụng.
    wire [31:0]  ex_alu_result;
    // EX: Đích nhánh/jump từ ALU; JALR đã xóa bit 0.
    wire [31:0]  ex_control_target;
    // EX: Yêu cầu nhảy/nhánh lấy; bộ điều khiển còn phải xét valid và ngoại lệ.
    wire         ex_control_taken;
    // EX: Đích nhánh/jump đang lấy không chia hết cho 4; cần cause 0.
    wire         ex_target_misaligned;
    // Lỗi căn chỉnh tại EX; đã xét valid/ngoại lệ, chưa xét MEM stall.
    wire         ex_fault_raw;
    // Cause 0/4/6 cho đích nhảy/load/store lệch hàng; dùng khi ex_fault_raw=1.
    wire [4:0]   ex_fault_cause;
    // MEM đang chờ data ready; giữ các tầng phía trước, WB cũ vẫn hoàn tất một lần.
    wire         mem_stall;
    // Lỗi data bus tại cạnh req && ready; chưa qua điều khiển pipeline.
    wire         mem_fault_raw;
    // MEM: Dữ liệu 32 bit đã chọn để ghi về thanh ghi đích.
    wire [31:0]  mem_wb_data;
    // Cho phép commit rd tại cạnh lên; đã chặn reset, lỗi, halt và x0.
    wire         wb_regfile_we;
    // Lệnh lỗi hợp lệ tại WB; sự kiện chốt trap và hủy các lệnh trẻ hơn.
    wire         wb_trap_event;
    // Core đã dừng do trap; giữ mức 1 đến reset.
    wire         halted_q;

    // Chọn rs1: 00=ID/EX, 01=WB, 10=MEM; không forward load sớm từ MEM.
    wire [1:0]   forward_rs1_sel;
    // Chọn rs2: 00=ID/EX, 01=WB, 10=MEM; MEM ưu tiên hơn WB.
    wire [1:0]   forward_rs2_sel;
    // Lỗi MEM được đưa tới điều khiển để loại các lệnh trẻ hơn.
    wire         mem_fault_event;
    // Lỗi EX được xử lý khi MEM không stall và không có lỗi già hơn.
    wire         ex_fault_event;
    // Nhánh/jump hợp lệ đổi PC; hủy lệnh trẻ và đáp ứng fetch sai đường.
    wire         ex_redirect_event;
    // Ngoại lệ ID được xử lý sau khi loại các sự kiện ưu tiên ở MEM/EX.
    wire         id_exception_event;
    // Dừng ID và chèn bubble vào EX vì dữ liệu load chưa sẵn sàng.
    wire         load_use_stall;
    // Xác nhận lấy đầu FIFO IF/ID tại cạnh lên; chỉ phát khi ID được tiến.
    wire         ifid_consumed;

    assign halted_o = halted_q;

    // IF: quản lý yêu cầu, FIFO lệnh và nhận/bỏ đáp ứng sai đường.
    rv32_if_stage #(.RESET_VECTOR(RESET_VECTOR)) u_if_stage (
        .clk_i(clk_i),
        .rst_i(rst_i),
        .halted_i(halted_q),
        .wb_trap_event_i(wb_trap_event),
        .mem_fault_event_i(mem_fault_event),
        .ex_fault_event_i(ex_fault_event),
        .ex_redirect_event_i(ex_redirect_event),
        .id_exception_event_i(id_exception_event),
        .ex_control_target_i(ex_control_target),
        .ifid_consumed_i(ifid_consumed),
        .imem_gnt_i(imem_gnt_i),
        .imem_rvalid_i(imem_rvalid_i),
        .imem_rdata_i(imem_rdata_i),
        .imem_err_i(imem_err_i),
        .imem_req_o(imem_req_o),
        .imem_addr_o(imem_addr_o),
        .debug_fetch_pc_o(debug_fetch_pc_o),
        .ifid_valid_o(ifid_valid_q),
        .ifid_pc_o(ifid_pc_q),
        .ifid_instr_o(ifid_instr_q),
        .ifid_exc_valid_o(ifid_exc_valid_q),
        .ifid_exc_cause_o(ifid_exc_cause_q)
    );

    // ID: giải mã RV32I, tạo immediate, đọc thanh ghi và bypass từ WB.
    rv32_id_stage u_id_stage (
        .clk_i(clk_i),
        .rst_i(rst_i),
        .instr_i(ifid_instr_q),
        .exc_valid_i(ifid_exc_valid_q),
        .exc_cause_i(ifid_exc_cause_q),
        .wb_regfile_we_i(wb_regfile_we),
        .memwb_rd_addr_i(memwb_rd_addr_q),
        .memwb_wb_data_i(memwb_wb_data_q),
        .rs1_addr_o(id_rs1_addr),
        .rs2_addr_o(id_rs2_addr),
        .rd_addr_o(id_rd_addr),
        .funct3_o(id_funct3),
        .rs1_data_o(id_rs1_data),
        .rs2_data_o(id_rs2_data),
        .imm_o(id_imm),
        .alu_op_o(id_alu_op),
        .op_a_sel_o(id_op_a_sel),
        .op_b_imm_o(id_op_b_imm),
        .reg_write_o(id_reg_write),
        .wb_sel_o(id_wb_sel),
        .branch_o(id_branch),
        .jal_o(id_jal),
        .jalr_o(id_jalr),
        .load_o(id_load),
        .store_o(id_store),
        .uses_rs1_o(id_uses_rs1),
        .uses_rs2_o(id_uses_rs2),
        .decode_exc_o(id_decode_exc),
        .any_exc_o(id_any_exc),
        .any_exc_cause_o(id_any_exc_cause)
    );

    // EX: forwarding toán hạng, ALU/nhánh và phát hiện địa chỉ lệch hàng.
    rv32_ex_stage u_ex_stage (
        .valid_i(idex_valid_q),
        .exc_valid_i(idex_exc_valid_q),
        .rs1_data_i(idex_rs1_data_q),
        .rs2_data_i(idex_rs2_data_q),
        .op_a_sel_i(idex_op_a_sel_q),
        .op_b_imm_i(idex_op_b_imm_q),
        .pc_i(idex_pc_q),
        .imm_i(idex_imm_q),
        .alu_op_i(idex_alu_op_q),
        .branch_i(idex_branch_q),
        .funct3_i(idex_funct3_q),
        .jal_i(idex_jal_q),
        .jalr_i(idex_jalr_q),
        .load_i(idex_load_q),
        .store_i(idex_store_q),
        .exmem_wb_sel_i(exmem_wb_sel_q),
        .exmem_pc4_i(exmem_pc4_q),
        .exmem_alu_result_i(exmem_alu_result_q),
        .memwb_wb_data_i(memwb_wb_data_q),
        .forward_rs1_sel_i(forward_rs1_sel),
        .forward_rs2_sel_i(forward_rs2_sel),
        .rs1_value_o(ex_rs1_value),
        .rs2_value_o(ex_rs2_value),
        .alu_result_o(ex_alu_result),
        .control_target_o(ex_control_target),
        .control_taken_o(ex_control_taken),
        .target_misaligned_o(ex_target_misaligned),
        .fault_raw_o(ex_fault_raw),
        .fault_cause_o(ex_fault_cause)
    );

    // MEM: giao dịch dữ liệu, chờ đáp ứng, phát hiện lỗi và chọn kết quả load.
    rv32_mem_stage u_mem_stage (
        .rst_i(rst_i),
        .halted_i(halted_q),
        .wb_trap_event_i(wb_trap_event),
        .valid_i(exmem_valid_q),
        .exc_valid_i(exmem_exc_valid_q),
        .load_i(exmem_load_q),
        .store_i(exmem_store_q),
        .alu_result_i(exmem_alu_result_q),
        .store_data_i(exmem_store_data_q),
        .funct3_i(exmem_funct3_q),
        .wb_sel_i(exmem_wb_sel_q),
        .pc4_i(exmem_pc4_q),
        .dmem_rdata_i(dmem_rdata_i),
        .dmem_ready_i(dmem_ready_i),
        .dmem_err_i(dmem_err_i),
        .dmem_req_o(dmem_req_o),
        .dmem_we_o(dmem_we_o),
        .dmem_addr_o(dmem_addr_o),
        .dmem_wdata_o(dmem_wdata_o),
        .dmem_wstrb_o(dmem_wstrb_o),
        .stall_o(mem_stall),
        .fault_raw_o(mem_fault_raw),
        .wb_data_o(mem_wb_data)
    );

    // WB: ghi thanh ghi, trace lệnh hoàn tất và chốt ngoại lệ chính xác.
    rv32_wb_stage u_wb_stage (
        .clk_i(clk_i),
        .rst_i(rst_i),
        .valid_i(memwb_valid_q),
        .exc_valid_i(memwb_exc_valid_q),
        .reg_write_i(memwb_reg_write_q),
        .rd_addr_i(memwb_rd_addr_q),
        .wb_data_i(memwb_wb_data_q),
        .pc_i(memwb_pc_q),
        .instr_i(memwb_instr_q),
        .exc_cause_i(memwb_exc_cause_q),
        .wb_regfile_we_o(wb_regfile_we),
        .wb_trap_event_o(wb_trap_event),
        .halted_o(halted_q),
        .trap_valid_o(trap_valid_o),
        .trap_cause_o(trap_cause_o),
        .trap_pc_o(trap_pc_o),
        .trap_instr_o(trap_instr_o),
        .retire_valid_o(retire_valid_o),
        .retire_pc_o(retire_pc_o),
        .retire_instr_o(retire_instr_o),
        .retire_rd_we_o(retire_rd_we_o),
        .retire_rd_addr_o(retire_rd_addr_o),
        .retire_rd_data_o(retire_rd_data_o)
    );

    // Điều khiển: hazard/forwarding; sự kiện của lệnh già hơn có ưu tiên cao hơn.
    rv32_pipeline_control u_control (
        .id_rs1_addr_i(id_rs1_addr),
        .id_rs2_addr_i(id_rs2_addr),
        .id_uses_rs1_i(id_uses_rs1),
        .id_uses_rs2_i(id_uses_rs2),
        .idex_valid_i(idex_valid_q),
        .idex_exc_valid_i(idex_exc_valid_q),
        .idex_load_i(idex_load_q),
        .idex_rd_addr_i(idex_rd_addr_q),
        .idex_rs1_addr_i(idex_rs1_addr_q),
        .idex_rs2_addr_i(idex_rs2_addr_q),
        .exmem_valid_i(exmem_valid_q),
        .exmem_exc_valid_i(exmem_exc_valid_q),
        .exmem_reg_write_i(exmem_reg_write_q),
        .exmem_load_i(exmem_load_q),
        .exmem_rd_addr_i(exmem_rd_addr_q),
        .memwb_valid_i(memwb_valid_q),
        .memwb_exc_valid_i(memwb_exc_valid_q),
        .memwb_reg_write_i(memwb_reg_write_q),
        .memwb_rd_addr_i(memwb_rd_addr_q),
        .mem_fault_raw_i(mem_fault_raw),
        .mem_stall_i(mem_stall),
        .ex_fault_raw_i(ex_fault_raw),
        .ex_control_taken_i(ex_control_taken),
        .ex_target_misaligned_i(ex_target_misaligned),
        .ifid_valid_i(ifid_valid_q),
        .ifid_exc_valid_i(ifid_exc_valid_q),
        .id_decode_exc_i(id_decode_exc),
        .halted_i(halted_q),
        .wb_trap_event_i(wb_trap_event),
        .forward_rs1_sel_o(forward_rs1_sel),
        .forward_rs2_sel_o(forward_rs2_sel),
        .mem_fault_event_o(mem_fault_event),
        .ex_fault_event_o(ex_fault_event),
        .ex_redirect_event_o(ex_redirect_event),
        .id_exception_event_o(id_exception_event),
        .load_use_stall_o(load_use_stall),
        .ifid_consumed_o(ifid_consumed)
    );

    // Thanh ghi ID/EX, EX/MEM và MEM/WB; IF/ID thuộc FIFO của IF.
    // Payload chỉ có nghĩa khi bit valid tương ứng bằng 1.
    always @(posedge clk_i) begin
        if (rst_i) begin
            idex_valid_q        <= 1'b0;
            idex_pc_q           <= 32'b0;
            idex_instr_q        <= 32'b0;
            idex_pc4_q          <= 32'b0;
            idex_rs1_addr_q     <= 5'b0;
            idex_rs2_addr_q     <= 5'b0;
            idex_rd_addr_q      <= 5'b0;
            idex_rs1_data_q     <= 32'b0;
            idex_rs2_data_q     <= 32'b0;
            idex_imm_q          <= 32'b0;
            idex_funct3_q       <= 3'b0;
            idex_alu_op_q       <= 4'b0;
            idex_op_a_sel_q     <= OP_A_RS1;
            idex_op_b_imm_q     <= 1'b0;
            idex_reg_write_q    <= 1'b0;
            idex_wb_sel_q       <= WB_ALU;
            idex_branch_q       <= 1'b0;
            idex_jal_q          <= 1'b0;
            idex_jalr_q         <= 1'b0;
            idex_load_q         <= 1'b0;
            idex_store_q        <= 1'b0;
            idex_exc_valid_q    <= 1'b0;
            idex_exc_cause_q    <= 5'b0;

            exmem_valid_q       <= 1'b0;
            exmem_pc_q          <= 32'b0;
            exmem_instr_q       <= 32'b0;
            exmem_pc4_q         <= 32'b0;
            exmem_rd_addr_q     <= 5'b0;
            exmem_reg_write_q   <= 1'b0;
            exmem_wb_sel_q      <= WB_ALU;
            exmem_alu_result_q  <= 32'b0;
            exmem_store_data_q  <= 32'b0;
            exmem_funct3_q      <= 3'b0;
            exmem_load_q        <= 1'b0;
            exmem_store_q       <= 1'b0;
            exmem_exc_valid_q   <= 1'b0;
            exmem_exc_cause_q   <= 5'b0;

            memwb_valid_q       <= 1'b0;
            memwb_pc_q          <= 32'b0;
            memwb_instr_q       <= 32'b0;
            memwb_rd_addr_q     <= 5'b0;
            memwb_reg_write_q   <= 1'b0;
            memwb_wb_data_q     <= 32'b0;
            memwb_exc_valid_q   <= 1'b0;
            memwb_exc_cause_q   <= 5'b0;

        end
        else if (wb_trap_event) begin
            idex_valid_q <= 1'b0;
            exmem_valid_q <= 1'b0;
            memwb_valid_q <= 1'b0;
        end
        else if (!halted_q) begin
            // ---------------------------- MEM/WB -------------------------
            if (mem_stall) begin
                // Lệnh WB cũ đã commit ở cạnh này; không được commit lặp.
                memwb_valid_q <= 1'b0;
            end
            else begin
                memwb_valid_q      <= exmem_valid_q;
                memwb_pc_q         <= exmem_pc_q;
                memwb_instr_q      <= exmem_instr_q;
                memwb_rd_addr_q    <= exmem_rd_addr_q;
                memwb_reg_write_q  <= exmem_reg_write_q &&
                                      !exmem_exc_valid_q &&
                                      !mem_fault_event;
                memwb_wb_data_q    <= mem_wb_data;
                memwb_exc_valid_q  <= exmem_exc_valid_q ||
                                      mem_fault_event;
                if (exmem_exc_valid_q) begin
                    memwb_exc_cause_q <= exmem_exc_cause_q;
                end
                else if (exmem_load_q) begin
                    memwb_exc_cause_q <= CAUSE_LOAD_ACCESS_FAULT;
                end
                else begin
                    memwb_exc_cause_q <= CAUSE_STORE_ACCESS_FAULT;
                end
            end

            // ---------------------------- EX/MEM -------------------------
            if (mem_fault_event) begin
                // MEM fault thuộc lệnh già hơn; hủy mọi kết quả từ EX.
                exmem_valid_q <= 1'b0;
            end
            else if (!mem_stall) begin
                exmem_valid_q      <= idex_valid_q;
                exmem_pc_q         <= idex_pc_q;
                exmem_instr_q      <= idex_instr_q;
                exmem_pc4_q        <= idex_pc4_q;
                exmem_rd_addr_q    <= idex_rd_addr_q;
                exmem_reg_write_q  <= idex_reg_write_q &&
                                      !idex_exc_valid_q &&
                                      !ex_fault_raw;
                exmem_wb_sel_q     <= idex_wb_sel_q;
                exmem_alu_result_q <= ex_alu_result;
                exmem_store_data_q <= ex_rs2_value;
                exmem_funct3_q     <= idex_funct3_q;
                exmem_load_q       <= idex_load_q &&
                                      !idex_exc_valid_q &&
                                      !ex_fault_raw;
                exmem_store_q      <= idex_store_q &&
                                      !idex_exc_valid_q &&
                                      !ex_fault_raw;
                exmem_exc_valid_q  <= idex_exc_valid_q || ex_fault_raw;
                exmem_exc_cause_q  <= idex_exc_valid_q
                                    ? idex_exc_cause_q
                                    : ex_fault_cause;
            end

            // ---------------------------- ID/EX --------------------------
            if (mem_fault_event || ex_fault_event || ex_redirect_event) begin
                idex_valid_q <= 1'b0;
            end
            else if (mem_stall) begin
                // WB có thể commit trong lúc MEM đang chờ. Chốt giá trị đã
                // forwarding vào ID/EX để consumer không mất dữ liệu sau
                // khi MEM/WB được clear ở chu kỳ stall kế tiếp.
                idex_rs1_data_q <= ex_rs1_value;
                idex_rs2_data_q <= ex_rs2_value;
            end
            else if (load_use_stall) begin
                idex_valid_q <= 1'b0;
            end
            else begin
                idex_valid_q      <= ifid_valid_q;
                idex_pc_q         <= ifid_pc_q;
                idex_instr_q      <= ifid_instr_q;
                idex_pc4_q        <= ifid_pc_q + 32'd4;
                idex_rs1_addr_q   <= id_rs1_addr;
                idex_rs2_addr_q   <= id_rs2_addr;
                idex_rd_addr_q    <= id_rd_addr;
                idex_rs1_data_q   <= id_rs1_data;
                idex_rs2_data_q   <= id_rs2_data;
                idex_imm_q        <= id_imm;
                idex_funct3_q     <= id_funct3;
                idex_alu_op_q     <= id_alu_op;
                idex_op_a_sel_q   <= id_op_a_sel;
                idex_op_b_imm_q   <= id_op_b_imm;
                idex_reg_write_q  <= id_reg_write && !id_any_exc;
                idex_wb_sel_q     <= id_wb_sel;
                idex_branch_q     <= id_branch && !id_any_exc;
                idex_jal_q        <= id_jal && !id_any_exc;
                idex_jalr_q       <= id_jalr && !id_any_exc;
                idex_load_q       <= id_load && !id_any_exc;
                idex_store_q      <= id_store && !id_any_exc;
                idex_exc_valid_q  <= id_any_exc;
                idex_exc_cause_q  <= id_any_exc_cause;
            end

        end
    end

endmodule

`default_nettype wire
