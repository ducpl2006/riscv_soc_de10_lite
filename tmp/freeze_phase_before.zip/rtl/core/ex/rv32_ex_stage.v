`default_nettype none
`include "rv32_defs.vh"

// EX: forwarding toán hạng, ALU/nhánh và kiểm tra địa chỉ lệch hàng.
// Logic tổ hợp, không giữ trạng thái. fault_raw được khóa bởi valid/exc_valid;
// bộ điều khiển core phân xử lỗi và redirect theo tuổi lệnh trước khi áp dụng.
// Chi tiết ranh giới pipeline: docs/giao_tiep_rtl_vi.md, mục 5.
module rv32_ex_stage (
    // 1: tầng đang chứa một lệnh; 0: bubble, không được tạo tác dụng phụ.
    input  wire         valid_i,
    // 1: lệnh đã mang ngoại lệ; chặn thực thi/ghi kết quả thông thường.
    input  wire         exc_valid_i,
    // Giá trị rs1 chốt trong ID/EX, trước mux forwarding.
    input  wire [31:0]  rs1_data_i,
    // Giá trị rs2 chốt trong ID/EX, trước mux forwarding.
    input  wire [31:0]  rs2_data_i,
    // Chọn toán hạng A: RV32_OP_A_RS1 / PC / ZERO.
    input  wire [1:0]   op_a_sel_i,
    // 1: ALU lấy immediate làm B; 0: lấy giá trị rs2.
    input  wire         op_b_imm_i,
    // Địa chỉ byte của lệnh đang xét, dùng cho đích nhánh và trace/trap.
    input  wire [31:0]  pc_i,
    // Immediate 32 bit: mở rộng dấu I/S/B/J; dạng U có 12 bit thấp bằng 0.
    input  wire [31:0]  imm_i,
    // Mã phép toán nội bộ RV32_ALU_* trong rv32_defs.vh.
    input  wire [3:0]   alu_op_i,
    // 1: lệnh nhánh có điều kiện; chưa có nghĩa là nhánh được lấy.
    input  wire         branch_i,
    // Trường instr[14:12], chọn điều kiện nhánh hoặc cỡ/kiểu load-store.
    input  wire [2:0]   funct3_i,
    // 1: lệnh JAL, nhảy tới PC + immediate và ghi PC+4 vào rd.
    input  wire         jal_i,
    // 1: lệnh JALR; đích rs1 + immediate phải xóa bit 0.
    input  wire         jalr_i,
    // 1: lệnh đọc bộ nhớ; cỡ đọc và mở rộng dấu do funct3 quyết định.
    input  wire         load_i,
    // 1: lệnh ghi bộ nhớ; cỡ ghi do funct3 quyết định.
    input  wire         store_i,
    // EX/MEM: Chọn nguồn ghi về: RV32_WB_ALU / LOAD / PC4.
    input  wire [1:0]   exmem_wb_sel_i,
    // EX/MEM: PC + 4 của lệnh đang xét; địa chỉ trở về cho JAL/JALR.
    input  wire [31:0]  exmem_pc4_i,
    // EX/MEM: Kết quả ALU 32 bit; với load/store là địa chỉ byte hiệu dụng.
    input  wire [31:0]  exmem_alu_result_i,
    // MEM/WB: Dữ liệu 32 bit đã chọn để ghi về thanh ghi đích.
    input  wire [31:0]  memwb_wb_data_i,
    // Chọn rs1: 00=ID/EX, 01=WB, 10=MEM; không forward load sớm từ MEM.
    input  wire [1:0]   forward_rs1_sel_i,
    // Chọn rs2: 00=ID/EX, 01=WB, 10=MEM; MEM ưu tiên hơn WB.
    input  wire [1:0]   forward_rs2_sel_i,
    // Giá trị rs1 sau chọn forwarding, dùng cho ALU/so sánh nhánh.
    output reg  [31:0]  rs1_value_o,
    // Giá trị rs2 sau forwarding, dùng cho ALU/nhánh và dữ liệu store.
    output reg  [31:0]  rs2_value_o,
    // Kết quả ALU 32 bit; với load/store là địa chỉ byte hiệu dụng.
    output wire [31:0]  alu_result_o,
    // Đích nhánh/jump từ ALU; JALR đã xóa bit 0.
    output wire [31:0]  control_target_o,
    // Yêu cầu nhảy/nhánh lấy; bộ điều khiển còn phải xét valid và ngoại lệ.
    output wire         control_taken_o,
    // Đích nhánh/jump đang lấy không chia hết cho 4; cần cause 0.
    output wire         target_misaligned_o,
    // Lỗi căn chỉnh khi valid && !exc_valid; cần phân xử với MEM trước khi xử lý.
    output wire         fault_raw_o,
    // Cause 0/4/6 cho đích nhảy/load/store lệch hàng; chỉ dùng khi fault_raw=1.
    output reg  [4:0]   fault_cause_o
);
    localparam [1:0] OP_A_PC = `RV32_OP_A_PC;
    localparam [1:0] OP_A_ZERO = `RV32_OP_A_ZERO;
    localparam [1:0] WB_PC4 = `RV32_WB_PC4;
    localparam [1:0] FWD_WB = `RV32_FWD_WB;
    localparam [1:0] FWD_MEM = `RV32_FWD_MEM;
    localparam [4:0] CAUSE_INSTR_ADDR_MISALIGNED = `RV32_CAUSE_INSTR_ADDR_MISALIGNED;
    localparam [4:0] CAUSE_LOAD_ADDR_MISALIGNED = `RV32_CAUSE_LOAD_ADDR_MISALIGNED;
    localparam [4:0] CAUSE_STORE_ADDR_MISALIGNED = `RV32_CAUSE_STORE_ADDR_MISALIGNED;

    // Kết quả sớm từ EX/MEM: PC+4 cho jump, ALU cho các lệnh khác.
    wire [31:0] mem_forward_data;
    assign mem_forward_data = (exmem_wb_sel_i == WB_PC4)
                            ? exmem_pc4_i
                            : exmem_alu_result_i;

    always @(*) begin
        case (forward_rs1_sel_i)
            FWD_MEM: rs1_value_o = mem_forward_data;
            FWD_WB : rs1_value_o = memwb_wb_data_i;
            default: rs1_value_o = rs1_data_i;
        endcase

        case (forward_rs2_sel_i)
            FWD_MEM: rs2_value_o = mem_forward_data;
            FWD_WB : rs2_value_o = memwb_wb_data_i;
            default: rs2_value_o = rs2_data_i;
        endcase
    end

    // -------------------------------------------------------------------------
    // EX: ALU, branch/jump target và kiểm tra alignment.
    // -------------------------------------------------------------------------
    // Toán hạng A thực tế vào ALU sau chọn rs1/PC/0.
    reg [31:0] ex_operand_a;
    // Toán hạng B thực tế vào ALU sau chọn immediate/rs2.
    wire [31:0] ex_operand_b;

    always @(*) begin
        case (op_a_sel_i)
            OP_A_PC  : ex_operand_a = pc_i;
            OP_A_ZERO: ex_operand_a = 32'b0;
            default  : ex_operand_a = rs1_value_o;
        endcase
    end
    assign ex_operand_b = op_b_imm_i ? imm_i : rs2_value_o;

    rv32_alu u_alu (
        .operand_a_i (ex_operand_a),
        .operand_b_i (ex_operand_b),
        .alu_op_i    (alu_op_i),
        .result_o    (alu_result_o)
    );

    // Kết quả so sánh branch đã khóa bởi valid và không có ngoại lệ.
    wire ex_branch_taken;
    rv32_branch_unit u_branch_unit (
        .branch_en_i    (branch_i && valid_i &&
                         !exc_valid_i),
        .funct3_i       (funct3_i),
        .rs1_data_i     (rs1_value_o),
        .rs2_data_i     (rs2_value_o),
        .branch_taken_o (ex_branch_taken)
    );

    // Decoder chọn PC/rs1 cộng immediate cho branch, JAL và JALR.
    // Tái sử dụng bộ cộng ALU làm đích; JALR xóa bit 0 trước kiểm tra căn chỉnh.
    assign control_target_o = jalr_i
                             ? {alu_result_o[31:1], 1'b0}
                             : alu_result_o;
    assign control_taken_o = jal_i || jalr_i ||
                              (branch_i && ex_branch_taken);
    assign target_misaligned_o = control_taken_o &&
                                  (control_target_o[1:0] != 2'b00);

    // Đầu ra phụ không sử dụng tại tầng này; nối tên riêng để thể hiện chủ đích.
    wire [31:0] ex_lsu_addr_unused;
    // Đầu ra phụ không sử dụng tại tầng này; nối tên riêng để thể hiện chủ đích.
    wire [31:0] ex_lsu_wdata_unused;
    // Đầu ra phụ không sử dụng tại tầng này; nối tên riêng để thể hiện chủ đích.
    wire [3:0]  ex_lsu_wstrb_unused;
    // Đầu ra phụ không sử dụng tại tầng này; nối tên riêng để thể hiện chủ đích.
    wire [31:0] ex_lsu_load_unused;
    // LSU kiểm tra địa chỉ load/store tại EX trước khi phát data bus.
    wire        ex_lsu_misaligned;

    rv32_lsu u_lsu_ex_check (
        .addr_i         (alu_result_o),
        .funct3_i       (funct3_i),
        .load_en_i      (load_i && valid_i &&
                         !exc_valid_i),
        .store_en_i     (store_i && valid_i &&
                         !exc_valid_i),
        .store_data_i   (rs2_value_o),
        .load_data_i    (32'b0),
        .mem_addr_o     (ex_lsu_addr_unused),
        .mem_wdata_o    (ex_lsu_wdata_unused),
        .mem_wstrb_o    (ex_lsu_wstrb_unused),
        .load_data_o    (ex_lsu_load_unused),
        .misaligned_o   (ex_lsu_misaligned)
    );

    assign fault_raw_o = valid_i && !exc_valid_i &&
                          (target_misaligned_o || ex_lsu_misaligned);

    always @(*) begin
        if (target_misaligned_o)
            fault_cause_o = CAUSE_INSTR_ADDR_MISALIGNED;
        else if (load_i)
            fault_cause_o = CAUSE_LOAD_ADDR_MISALIGNED;
        else
            fault_cause_o = CAUSE_STORE_ADDR_MISALIGNED;
    end

endmodule

`default_nettype wire
