`default_nettype none
`include "rv32_defs.vh"

// =============================================================================
// Khối lấy lệnh: kênh yêu cầu/đáp ứng độc lập, FIFO hai phần tử.
// Clock: cạnh lên clk_i; reset đồng bộ, tích cực cao.
// Yêu cầu được nhận khi req && gnt; giữ req/addr tới cạnh nhận, kể cả khi flush.
// Mỗi yêu cầu được nhận phải có đúng một đáp ứng, đúng thứ tự, sớm nhất ở cạnh
// kế tiếp. Kênh đáp ứng không có back-pressure; rdata/err chỉ hợp lệ khi rvalid.
// Tổng FIFO + yêu cầu đã nhận + yêu cầu đang giữ không vượt quá hai phần tử.
// ifid_consumed_i xác nhận ID lấy phần tử đầu; bên điều khiển phải chặn tín
// hiệu này khi stall hoặc có sự kiện ưu tiên cao hơn. Flush thắng cập nhật FIFO.
// Cờ kill lưu riêng từng yêu cầu và chỉ xóa khi thay bằng yêu cầu mới, tránh
// khôi phục nhầm yêu cầu cũ khi nhiều sự kiện flush xảy ra liên tiếp.
// Reset phải áp dụng đồng thời cho core và memory, hủy mọi đáp ứng chưa trả.
// Hợp đồng đầy đủ: docs/giao_tiep_rtl_vi.md.
// =============================================================================
module rv32_if_stage #(
    // PC khởi động (địa chỉ byte); nên căn 4, lệch hàng sẽ tạo trap tại IF.
    parameter [31:0] RESET_VECTOR = 32'h0000_0000
) (
    // Clock hệ thống; mạch tuần tự cập nhật tại cạnh lên.
    input  wire         clk_i,
    // Reset tích cực cao; xóa trạng thái tại cạnh lên, đồng thời chặn giao dịch mới.
    input  wire         rst_i,
    // Core đã dừng do trap; giữ mức 1 đến reset.
    input  wire         halted_i,
    // Lệnh lỗi hợp lệ tại WB; sự kiện chốt trap và hủy các lệnh trẻ hơn.
    input  wire         wb_trap_event_i,
    // Lỗi MEM được đưa tới điều khiển để loại các lệnh trẻ hơn.
    input  wire         mem_fault_event_i,
    // Lỗi EX được xử lý khi MEM không stall và không có lỗi già hơn.
    input  wire         ex_fault_event_i,
    // Nhánh/jump hợp lệ đổi PC; hủy lệnh trẻ và đáp ứng fetch sai đường.
    input  wire         ex_redirect_event_i,
    // Ngoại lệ ID được xử lý sau khi loại các sự kiện ưu tiên ở MEM/EX.
    input  wire         id_exception_event_i,
    // EX: Đích nhánh/jump từ ALU; JALR đã xóa bit 0.
    input  wire [31:0]  ex_control_target_i,
    // Xác nhận lấy đầu FIFO IF/ID tại cạnh lên; chỉ phát khi ID được tiến.
    input  wire         ifid_consumed_i,
    // Memory nhận yêu cầu tại cạnh req && gnt; chưa phải dữ liệu trả về.
    input  wire         imem_gnt_i,
    // Có đáp ứng cho yêu cầu đã grant trước đó; không có rready.
    input  wire         imem_rvalid_i,
    // Word lệnh trả về; chỉ dùng khi rvalid=1 và err=0.
    input  wire [31:0]  imem_rdata_i,
    // Lỗi lấy lệnh; chỉ xét cùng rvalid, tạo cause 1 nếu đúng đường.
    input  wire         imem_err_i,
    // Yêu cầu lấy lệnh; giữ mức 1 cùng địa chỉ tới cạnh req && gnt.
    output wire         imem_req_o,
    // Địa chỉ byte lấy lệnh, căn 4; giữ ổn định khi req && !gnt.
    output wire [31:0]  imem_addr_o,
    // PC cho yêu cầu fetch mới; không phải PC retire hay địa chỉ đang giữ chờ grant.
    output wire [31:0]  debug_fetch_pc_o,
    // IF/ID: 1: tầng đang chứa một lệnh; 0: bubble, không được tạo tác dụng phụ.
    output wire         ifid_valid_o,
    // IF/ID: Địa chỉ byte của lệnh đang xét, dùng cho đích nhánh và trace/trap.
    output wire [31:0]  ifid_pc_o,
    // IF/ID: Mã lệnh RV32I 32 bit của lệnh đang xét.
    output wire [31:0]  ifid_instr_o,
    // IF/ID: 1: lệnh đã mang ngoại lệ; chặn thực thi/ghi kết quả thông thường.
    output wire         ifid_exc_valid_o,
    // IF/ID: Mã nguyên nhân ngoại lệ; chỉ có nghĩa khi exc_valid=1.
    output wire [4:0]   ifid_exc_cause_o
);
    localparam [4:0] CAUSE_INSTR_ADDR_MISALIGNED =
        `RV32_CAUSE_INSTR_ADDR_MISALIGNED;
    localparam [4:0] CAUSE_INSTR_ACCESS_FAULT =
        `RV32_CAUSE_INSTR_ACCESS_FAULT;

    // Dừng tạo request mới do ngoại lệ/halt; redirect hợp lệ có thể cho fetch chạy lại.
    reg         front_stop_q;
    // PC cho request mới; tăng 4 khi request đúng đường được grant, hoặc nạp đích redirect.
    reg  [31:0] fetch_pc_q;

    // Giữ nguyên yêu cầu đã phát trong khi chờ grant.
    // Đã phát request nhưng chưa grant; phải giữ req/địa chỉ tới khi nhận.
    reg         req_hold_valid_q;
    // PC của request đang chờ grant; không đổi khi có redirect.
    reg  [31:0] req_hold_pc_q;
    // Request chờ grant thuộc đường bị hủy; vẫn phải grant rồi bỏ response.
    reg         req_hold_kill_q;

    // Hàng đợi PC và trạng thái hủy, theo thứ tự yêu cầu được nhận.
    // Số request đã grant còn chờ response (0..2), theo thứ tự nhận.
    reg  [1:0]  req_count_q;
    // PC của request đã grant lâu nhất, ứng với response kế tiếp.
    reg  [31:0] req_pc0_q;
    // PC của request đã grant thứ hai nếu req_count_q=2.
    reg  [31:0] req_pc1_q;
    // Đánh dấu bỏ response của request đầu; dùng giải phóng credit dù sai đường.
    reg         req_kill0_q;
    // Đánh dấu bỏ response của request thứ hai; giữ qua nhiều lần redirect.
    reg         req_kill1_q;

    // Phần tử số 0 của FIFO là đầu ra IF/ID.
    // Số lệnh/ngoại lệ đã nhận đang nằm trong FIFO IF/ID (0..2).
    reg  [1:0]  fifo_count_q;
    // PC đầu FIFO, đưa sang ID khi ifid_valid=1.
    reg  [31:0] fifo_pc0_q;
    // PC phần tử thứ hai trong FIFO, có nghĩa khi fifo_count_q=2.
    reg  [31:0] fifo_pc1_q;
    // Mã lệnh đầu FIFO; bằng 0 cho phần tử fetch fault.
    reg  [31:0] fifo_instr0_q;
    // Mã lệnh thứ hai trong FIFO, có nghĩa khi fifo_count_q=2.
    reg  [31:0] fifo_instr1_q;
    // Đầu FIFO mang ngoại lệ fetch thay vì lệnh bình thường.
    reg         fifo_exc0_q;
    // Phần tử FIFO thứ hai mang ngoại lệ fetch.
    reg         fifo_exc1_q;
    // Cause đầu FIFO; chỉ xét khi fifo_exc0_q=1 và FIFO không rỗng.
    reg  [4:0]  fifo_cause0_q;
    // Cause phần tử thứ hai; chỉ xét khi fifo_exc1_q=1 và có phần tử đó.
    reg  [4:0]  fifo_cause1_q;

    // Có sự kiện pipeline cần xóa FIFO và hủy request fetch cũ.
    wire        external_flush_event;
    // Sự kiện dừng fetch vì lỗi/halt; redirect đơn thuần không thuộc nhóm này.
    wire        stop_event;
    // ID lấy một phần tử hợp lệ khỏi FIFO tại cạnh lên.
    wire        fifo_pop;
    // Tổng credit đã chiếm: FIFO + request đã grant + request đang giữ.
    wire [2:0]  frontend_used;
    // Còn chỗ cho response mới, hoặc ID đang giải phóng một chỗ cùng cạnh.
    wire        issue_has_credit;
    // Được tạo request mới: còn credit, PC căn hàng và frontend không bị chặn.
    wire        new_request_valid;
    // Handshake instruction req && gnt tại cạnh lên.
    wire        request_accept;
    // Request mới chưa được grant; cần chốt PC để giữ payload ổn định.
    wire        request_capture_hold;
    // PC gắn với request hiện tại: PC đang giữ nếu có, ngược lại fetch_pc_q.
    wire [31:0] request_pc;
    // Request hiện tại đã bị hủy khi còn chờ grant.
    wire        request_kill;
    // Request chưa bị hủy và không gặp flush ở chu kỳ hiện tại.
    wire        request_live;
    // Response đến và có metadata request đang chờ; lấy metadata đầu hàng đợi.
    wire        response_pop;
    // Response đúng đường, không bị flush/stop; được đưa vào FIFO.
    wire        response_live;
    // Có response đúng đường để đẩy lệnh hoặc fetch fault vào FIFO.
    wire        response_push;
    // Tạo phần tử cause 0 cho PC fetch lệch hàng mà không phát memory request.
    wire        local_misaligned_push;
    // Thêm một phần tử từ response hoặc lỗi PC cục bộ vào FIFO.
    wire        fifo_push;
    // PC gắn với phần tử mới đưa vào FIFO.
    wire [31:0] push_pc;
    // Word lệnh mới; bằng 0 nếu lỗi fetch hoặc lỗi PC cục bộ.
    wire [31:0] push_instr;
    // Cờ ngoại lệ của phần tử mới; chỉ có nghĩa khi fifo_push=1.
    wire        push_exc;
    // Cause 0 cho PC lệch hàng, cause 1 cho lỗi truy cập instruction.
    wire [4:0]  push_cause;
    // Response đúng đường báo lỗi; dừng phát request trẻ hơn.
    wire        fetch_exception_event;

    assign external_flush_event = wb_trap_event_i || halted_i ||
                                  mem_fault_event_i || ex_fault_event_i ||
                                  ex_redirect_event_i ||
                                  id_exception_event_i;
    assign stop_event = wb_trap_event_i || halted_i ||
                        mem_fault_event_i || ex_fault_event_i ||
                        id_exception_event_i;

    assign ifid_valid_o     = (fifo_count_q != 2'd0);
    assign ifid_pc_o        = fifo_pc0_q;
    assign ifid_instr_o     = fifo_instr0_q;
    assign ifid_exc_valid_o = fifo_exc0_q;
    assign ifid_exc_cause_o = fifo_cause0_q;

    assign fifo_pop = ifid_consumed_i && ifid_valid_o;
    assign frontend_used = {1'b0, fifo_count_q} +
                           {1'b0, req_count_q} +
                           {2'b0, req_hold_valid_q};
    assign issue_has_credit = (frontend_used < 3'd2) || fifo_pop;

    assign new_request_valid = !halted_i && !front_stop_q &&
                               !external_flush_event && issue_has_credit &&
                               (fetch_pc_q[1:0] == 2'b00);
    assign imem_req_o = !rst_i && (req_hold_valid_q || new_request_valid);
    assign imem_addr_o = req_hold_valid_q ? req_hold_pc_q : fetch_pc_q;
    assign request_accept = imem_req_o && imem_gnt_i;
    assign request_capture_hold = !rst_i && !req_hold_valid_q &&
                                  new_request_valid && !imem_gnt_i;
    assign request_pc = req_hold_valid_q ? req_hold_pc_q : fetch_pc_q;
    assign request_kill = req_hold_valid_q && req_hold_kill_q;
    assign request_live = !request_kill &&
                          !external_flush_event;

    // Mỗi đáp ứng lấy metadata đầu hàng đợi, kể cả đáp ứng đã bị hủy.
    assign response_pop = imem_rvalid_i && (req_count_q != 2'd0);
    assign response_live = response_pop &&
                           !req_kill0_q &&
                           !external_flush_event && !front_stop_q;
    assign response_push = response_live;
    assign fetch_exception_event = response_push && imem_err_i;

    // Vector reset lệch hàng tạo ngoại lệ tại IF; đích nhánh được kiểm tra ở EX.
    assign local_misaligned_push = !rst_i && !halted_i &&
                                   !front_stop_q &&
                                   !external_flush_event &&
                                   (req_count_q == 2'd0) &&
                                   !req_hold_valid_q &&
                                   issue_has_credit &&
                                   (fetch_pc_q[1:0] != 2'b00);
    assign fifo_push = response_push || local_misaligned_push;
    assign push_pc = response_push ? req_pc0_q : fetch_pc_q;
    assign push_instr = (response_push && !imem_err_i)
                      ? imem_rdata_i : 32'b0;
    assign push_exc = local_misaligned_push || imem_err_i;
    assign push_cause = local_misaligned_push
                      ? CAUSE_INSTR_ADDR_MISALIGNED
                      : CAUSE_INSTR_ACCESS_FAULT;

    assign debug_fetch_pc_o = fetch_pc_q;

    always @(posedge clk_i) begin
        if (rst_i) begin
            front_stop_q   <= 1'b0;
            fetch_pc_q     <= RESET_VECTOR;
            req_hold_valid_q <= 1'b0;
            req_hold_pc_q  <= 32'b0;
            req_hold_kill_q <= 1'b0;
            req_count_q    <= 2'd0;
            req_pc0_q      <= 32'b0;
            req_pc1_q      <= 32'b0;
            req_kill0_q    <= 1'b0;
            req_kill1_q    <= 1'b0;
            fifo_count_q   <= 2'd0;
            fifo_pc0_q     <= 32'b0;
            fifo_pc1_q     <= 32'b0;
            fifo_instr0_q  <= 32'b0;
            fifo_instr1_q  <= 32'b0;
            fifo_exc0_q    <= 1'b0;
            fifo_exc1_q    <= 1'b0;
            fifo_cause0_q  <= 5'b0;
            fifo_cause1_q  <= 5'b0;
        end
        else begin
            if (ex_redirect_event_i)
                fetch_pc_q <= ex_control_target_i;
            else if (request_accept && request_live)
                fetch_pc_q <= request_pc + 32'd4;

            if (request_accept)
                req_hold_valid_q <= 1'b0;
            else if (request_capture_hold) begin
                req_hold_valid_q <= 1'b1;
                req_hold_pc_q <= fetch_pc_q;
                req_hold_kill_q <= 1'b0;
            end

            if (stop_event || fetch_exception_event ||
                local_misaligned_push)
                front_stop_q <= 1'b1;
            else if (ex_redirect_event_i)
                front_stop_q <= 1'b0;

            // Cập nhật hàng đợi yêu cầu chưa có đáp ứng.
            case ({request_accept, response_pop})
                2'b10: begin
                    if (req_count_q == 2'd0) begin
                        req_pc0_q    <= request_pc;
                        req_kill0_q  <= request_kill;
                    end
                    else begin
                        req_pc1_q    <= request_pc;
                        req_kill1_q  <= request_kill;
                    end
                    req_count_q <= req_count_q + 2'd1;
                end
                2'b01: begin
                    if (req_count_q == 2'd2) begin
                        req_pc0_q    <= req_pc1_q;
                        req_kill0_q  <= req_kill1_q;
                    end
                    req_count_q <= req_count_q - 2'd1;
                end
                2'b11: begin
                    if (req_count_q == 2'd1) begin
                        req_pc0_q    <= request_pc;
                        req_kill0_q  <= request_kill;
                    end
                    else begin
                        req_pc0_q    <= req_pc1_q;
                        req_kill0_q  <= req_kill1_q;
                        req_pc1_q    <= request_pc;
                        req_kill1_q  <= request_kill;
                    end
                end
                default: begin end
            endcase

            // Ưu tiên hủy sau cập nhật hàng đợi: cả yêu cầu vừa được grant hoặc
            // vừa chuyển sang trạng thái giữ trong chu kỳ lỗi đều phải bị hủy.
            if (external_flush_event || fetch_exception_event ||
                local_misaligned_push) begin
                req_hold_kill_q <= 1'b1;
                req_kill0_q <= 1'b1;
                req_kill1_q <= 1'b1;
            end

            // Flush xóa FIFO; giữ metadata để nhận và loại bỏ đáp ứng cũ.
            if (external_flush_event) begin
                fifo_count_q <= 2'd0;
            end
            else begin
                case ({fifo_push, fifo_pop})
                    2'b10: begin
                        if (fifo_count_q == 2'd0) begin
                            fifo_pc0_q    <= push_pc;
                            fifo_instr0_q <= push_instr;
                            fifo_exc0_q   <= push_exc;
                            fifo_cause0_q <= push_cause;
                        end
                        else begin
                            fifo_pc1_q    <= push_pc;
                            fifo_instr1_q <= push_instr;
                            fifo_exc1_q   <= push_exc;
                            fifo_cause1_q <= push_cause;
                        end
                        fifo_count_q <= fifo_count_q + 2'd1;
                    end
                    2'b01: begin
                        if (fifo_count_q == 2'd2) begin
                            fifo_pc0_q    <= fifo_pc1_q;
                            fifo_instr0_q <= fifo_instr1_q;
                            fifo_exc0_q   <= fifo_exc1_q;
                            fifo_cause0_q <= fifo_cause1_q;
                        end
                        fifo_count_q <= fifo_count_q - 2'd1;
                    end
                    2'b11: begin
                        if (fifo_count_q == 2'd1) begin
                            fifo_pc0_q    <= push_pc;
                            fifo_instr0_q <= push_instr;
                            fifo_exc0_q   <= push_exc;
                            fifo_cause0_q <= push_cause;
                        end
                        else begin
                            fifo_pc0_q    <= fifo_pc1_q;
                            fifo_instr0_q <= fifo_instr1_q;
                            fifo_exc0_q   <= fifo_exc1_q;
                            fifo_cause0_q <= fifo_cause1_q;
                            fifo_pc1_q    <= push_pc;
                            fifo_instr1_q <= push_instr;
                            fifo_exc1_q   <= push_exc;
                            fifo_cause1_q <= push_cause;
                        end
                    end
                    default: begin end
                endcase
            end
        end
    end

endmodule

`default_nettype wire
